package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.Links
import kotlin-spring-server.models.Meta
import kotlin-spring-server.models.PersonalFinancialRelationData
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * 
 * @param &#x60;data&#x60; 
 * @param links 
 * @param meta 
 */
data class ResponsePersonalCustomersFinancialRelation(

    @field:Valid
    @field:JsonProperty("data", required = true) val `data`: PersonalFinancialRelationData,

    @field:Valid
    @field:JsonProperty("links", required = true) val links: Links,

    @field:Valid
    @field:JsonProperty("meta", required = true) val meta: Meta
) {

}

