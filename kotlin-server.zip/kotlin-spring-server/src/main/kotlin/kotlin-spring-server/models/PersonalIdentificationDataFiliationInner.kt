package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.EnumFiliationType
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * 
 * @param type 
 * @param civilName Nome civil completo da pessoa relativa à filiação. (Direito fundamental da pessoa, o nome civil é aquele atribuído à pessoa natural desde o registro de seu nascimento,  com o qual será identificada por toda a sua vida, bem como após a sua morte) 
 * @param socialName Nome social da pessoa natural, se houver.  (aquele pelo qual travestis e transexuais se reconhecem,  bem como são identificados por sua comunidade e em seu meio social, conforme Decreto Local) 
 */
data class PersonalIdentificationDataFiliationInner(

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @field:JsonProperty("type", required = true) val type: EnumFiliationType,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @Schema(example = "Marcelo Cláudio Fernandes", required = true, description = "Nome civil completo da pessoa relativa à filiação. (Direito fundamental da pessoa, o nome civil é aquele atribuído à pessoa natural desde o registro de seu nascimento,  com o qual será identificada por toda a sua vida, bem como após a sua morte) ")
    @field:JsonProperty("civilName", required = true) val civilName: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @Schema(example = "NA", description = "Nome social da pessoa natural, se houver.  (aquele pelo qual travestis e transexuais se reconhecem,  bem como são identificados por sua comunidade e em seu meio social, conforme Decreto Local) ")
    @field:JsonProperty("socialName") val socialName: kotlin.String? = null
) {

}

