package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonValue
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
* Enumeração referente a cada sigla da unidade da federação que identifica o estado ou o distrito federal, no qual o endereço está localizado. p.ex. 'AC'. São consideradas apenas as siglas para os estados brasileiros
* Values: aC,aL,aP,aM,bA,cE,dF,eS,gO,mA,mT,mS,mG,pA,pB,pR,pE,pI,rJ,rN,rS,rO,rR,sC,sP,sE,tO,nA
*/
enum class EnumCountrySubDivision(val value: kotlin.String) {

    @JsonProperty("AC") aC("AC"),
    @JsonProperty("AL") aL("AL"),
    @JsonProperty("AP") aP("AP"),
    @JsonProperty("AM") aM("AM"),
    @JsonProperty("BA") bA("BA"),
    @JsonProperty("CE") cE("CE"),
    @JsonProperty("DF") dF("DF"),
    @JsonProperty("ES") eS("ES"),
    @JsonProperty("GO") gO("GO"),
    @JsonProperty("MA") mA("MA"),
    @JsonProperty("MT") mT("MT"),
    @JsonProperty("MS") mS("MS"),
    @JsonProperty("MG") mG("MG"),
    @JsonProperty("PA") pA("PA"),
    @JsonProperty("PB") pB("PB"),
    @JsonProperty("PR") pR("PR"),
    @JsonProperty("PE") pE("PE"),
    @JsonProperty("PI") pI("PI"),
    @JsonProperty("RJ") rJ("RJ"),
    @JsonProperty("RN") rN("RN"),
    @JsonProperty("RS") rS("RS"),
    @JsonProperty("RO") rO("RO"),
    @JsonProperty("RR") rR("RR"),
    @JsonProperty("SC") sC("SC"),
    @JsonProperty("SP") sP("SP"),
    @JsonProperty("SE") sE("SE"),
    @JsonProperty("TO") tO("TO"),
    @JsonProperty("NA") nA("NA")
}

