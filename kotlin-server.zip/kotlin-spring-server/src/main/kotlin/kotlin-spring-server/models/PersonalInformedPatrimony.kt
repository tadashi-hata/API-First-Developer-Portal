package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * 
 * @param amount Valor do patrimônio informado. Expresso em valor monetário com 4 casas decimais. Patrimônio é o conjunto de bens vinculado a uma pessoa ou a uma entidade. 
 * @param currency Moeda referente ao valor do patrimônio, segundo modelo ISO-4217.
 * @param year Ano de referência do Patrimônio, conforme especificação RFC-3339.
 */
data class PersonalInformedPatrimony(

    @field:JsonProperty("amount", required = true) val amount: kotlin.Double,
    @get:Pattern(regexp="^(\\w{3}){1}$|^NA$")
    @get:Size(max=3)
    @field:JsonProperty("currency", required = true) val currency: kotlin.String,

    @get:DecimalMax("9999")
    @field:JsonProperty("year", required = true) val year: java.math.BigDecimal
) {

}

