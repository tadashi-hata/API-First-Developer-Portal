package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
* Número de DDD (Discagem Direta à Distância) do telefone do cliente - se houver
* Values: _11,_12,_13,_14,_15,_16,_17,_18,_19,_21,_22,_24,_27,_28,_31,_32,_33,_34,_35,_37,_38,_41,_42,_43,_44,_45,_46,_47,_48,_49,_51,_53,_54,_55,_61,_62,_63,_64,_65,_66,_67,_68,_69,_71,_73,_74,_75,_77,_79,_81,_82,_83,_84,_85,_86,_87,_88,_89,_91,_92,_93,_94,_95,_96,_97,_98,_99,nA
*/
enum class EnumAreaCode(val value: kotlin.String) {

    @JsonProperty("11") _11("11"),

    @JsonProperty("12") _12("12"),

    @JsonProperty("13") _13("13"),

    @JsonProperty("14") _14("14"),

    @JsonProperty("15") _15("15"),

    @JsonProperty("16") _16("16"),

    @JsonProperty("17") _17("17"),

    @JsonProperty("18") _18("18"),

    @JsonProperty("19") _19("19"),

    @JsonProperty("21") _21("21"),

    @JsonProperty("22") _22("22"),

    @JsonProperty("24") _24("24"),

    @JsonProperty("27") _27("27"),

    @JsonProperty("28") _28("28"),

    @JsonProperty("31") _31("31"),

    @JsonProperty("32") _32("32"),

    @JsonProperty("33") _33("33"),

    @JsonProperty("34") _34("34"),

    @JsonProperty("35") _35("35"),

    @JsonProperty("37") _37("37"),

    @JsonProperty("38") _38("38"),

    @JsonProperty("41") _41("41"),

    @JsonProperty("42") _42("42"),

    @JsonProperty("43") _43("43"),

    @JsonProperty("44") _44("44"),

    @JsonProperty("45") _45("45"),

    @JsonProperty("46") _46("46"),

    @JsonProperty("47") _47("47"),

    @JsonProperty("48") _48("48"),

    @JsonProperty("49") _49("49"),

    @JsonProperty("51") _51("51"),

    @JsonProperty("53") _53("53"),

    @JsonProperty("54") _54("54"),

    @JsonProperty("55") _55("55"),

    @JsonProperty("61") _61("61"),

    @JsonProperty("62") _62("62"),

    @JsonProperty("63") _63("63"),

    @JsonProperty("64") _64("64"),

    @JsonProperty("65") _65("65"),

    @JsonProperty("66") _66("66"),

    @JsonProperty("67") _67("67"),

    @JsonProperty("68") _68("68"),

    @JsonProperty("69") _69("69"),

    @JsonProperty("71") _71("71"),

    @JsonProperty("73") _73("73"),

    @JsonProperty("74") _74("74"),

    @JsonProperty("75") _75("75"),

    @JsonProperty("77") _77("77"),

    @JsonProperty("79") _79("79"),

    @JsonProperty("81") _81("81"),

    @JsonProperty("82") _82("82"),

    @JsonProperty("83") _83("83"),

    @JsonProperty("84") _84("84"),

    @JsonProperty("85") _85("85"),

    @JsonProperty("86") _86("86"),

    @JsonProperty("87") _87("87"),

    @JsonProperty("88") _88("88"),

    @JsonProperty("89") _89("89"),

    @JsonProperty("91") _91("91"),

    @JsonProperty("92") _92("92"),

    @JsonProperty("93") _93("93"),

    @JsonProperty("94") _94("94"),

    @JsonProperty("95") _95("95"),

    @JsonProperty("96") _96("96"),

    @JsonProperty("97") _97("97"),

    @JsonProperty("98") _98("98"),

    @JsonProperty("99") _99("99"),

    @JsonProperty("NA") nA("NA");

}

