package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonValue
import kotlin-spring-server.models.EnumPersonalOtherDocumentType
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * 
 * @param type 
 * @param typeAdditionalInfo Campo livre de preenchimento obrigatório se selecionada a opção OUTROS tipos de documentos
 * @param number Identificação/Número do documento informado
 * @param checkDigit Dígito verificador do documento informado. De preenchimento obrigatório se o documento informado tiver dígito verificador
 * @param expirationDate Data de validade do documento informado, conforme especificação RFC-3339.
 * @param additionalInfo Para documentos em que se aplique o uso do local de emissão o mesmo deve ser enviado mandatoriamente, com a informação de órgão e UF. Exemplo: RG, local de emissão: SSP/RS. [Restrição] Obrigatório quando o Local de Emissão do Documento for relevante. 
 */
data class PersonalOtherDocument(

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @get:JsonProperty("type", required = true) val type: EnumPersonalOtherDocumentType,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @Schema(example = "NA", required = true, description = "Campo livre de preenchimento obrigatório se selecionada a opção OUTROS tipos de documentos")
    @get:JsonProperty("typeAdditionalInfo", required = true) val typeAdditionalInfo: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=11)
    @Schema(example = "15291908", required = true, description = "Identificação/Número do documento informado")
    @get:JsonProperty("number", required = true) val number: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=2)
    @Schema(example = "P", required = true, description = "Dígito verificador do documento informado. De preenchimento obrigatório se o documento informado tiver dígito verificador")
    @get:JsonProperty("checkDigit", required = true) val checkDigit: kotlin.String,

    @field:Valid
    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])$|^NA$")
    @get:Size(max=10)
    @Schema(example = "Fri May 21 00:00:00 UTC 2021", required = true, description = "Data de validade do documento informado, conforme especificação RFC-3339.")
    @get:JsonProperty("expirationDate", required = true) val expirationDate: java.time.LocalDate,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=50)
    @Schema(example = "SSP/SP", description = "Para documentos em que se aplique o uso do local de emissão o mesmo deve ser enviado mandatoriamente, com a informação de órgão e UF. Exemplo: RG, local de emissão: SSP/RS. [Restrição] Obrigatório quando o Local de Emissão do Documento for relevante. ")
    @get:JsonProperty("additionalInfo") val additionalInfo: kotlin.String? = null
) {

}

