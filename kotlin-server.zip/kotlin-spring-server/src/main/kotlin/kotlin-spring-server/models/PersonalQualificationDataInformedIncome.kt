package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.EnumInformedIncomeFrequency
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * 
 * @param frequency 
 * @param amount Valor total da renda informada. Expresso em valor monetário com 4 casas decimais.  Renda primária indica os montantes a pagar ou a receber em troca do uso temporário de recursos financeiros, trabalho ou ativos não financeiros não produzidos, a saber, remuneração de trabalhadores, renda de investimentos e demais rendas primárias. Fazem parte da primeira a remuneração do trabalho assalariado (salários e ordenados); da segunda, renda de investimento direto, renda de investimento em carteira, renda de outros investimentos e renda de ativos de reserva; e da terceira, tributos sobre a produção e importação, subsídios e aluguéis. Fonte: Banco Central do Brasil – Departamento Econômico 
 * @param currency Moeda referente ao valor da renda, segundo modelo ISO-4217.
 * @param date Data da renda, conforme especificação RFC-3339.
 */
data class PersonalQualificationDataInformedIncome(

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @field:JsonProperty("frequency", required = true) val frequency: EnumInformedIncomeFrequency,

    @Schema(example = "100000.04", required = true, description = "Valor total da renda informada. Expresso em valor monetário com 4 casas decimais.  Renda primária indica os montantes a pagar ou a receber em troca do uso temporário de recursos financeiros, trabalho ou ativos não financeiros não produzidos, a saber, remuneração de trabalhadores, renda de investimentos e demais rendas primárias. Fazem parte da primeira a remuneração do trabalho assalariado (salários e ordenados); da segunda, renda de investimento direto, renda de investimento em carteira, renda de outros investimentos e renda de ativos de reserva; e da terceira, tributos sobre a produção e importação, subsídios e aluguéis. Fonte: Banco Central do Brasil – Departamento Econômico ")
    @field:JsonProperty("amount", required = true) val amount: kotlin.Double,

    @get:Pattern(regexp="^(\\w{3}){1}$|^NA$")
    @get:Size(max=3)
    @Schema(example = "BRL", required = true, description = "Moeda referente ao valor da renda, segundo modelo ISO-4217.")
    @field:JsonProperty("currency", required = true) val currency: kotlin.String,

    @field:Valid
    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])$|^NA$")
    @get:Size(max=10)
    @Schema(example = "Fri May 21 00:00:00 UTC 2021", required = true, description = "Data da renda, conforme especificação RFC-3339.")
    @field:JsonProperty("date", required = true) val date: java.time.LocalDate
) {

}

