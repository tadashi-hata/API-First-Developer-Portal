package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
* Tipo de representante. Representante legal - Nome Civil completo da Pessoa Natural que represente uma entidade ou uma empresa e é nomeado em seu ato constitutivo, ou seja, no contrato social ou estatuto social. Procurador - é qualquer pessoa que represente a Pessoa Natural em algum negócio, mediante autorização escrita do mesmo. 
* Values: rEPRESENTANTELEGAL,pROCURADOR,nAOAPLICA
*/
enum class EnumProcuratorsTypePersonal(val value: kotlin.String) {

    @JsonProperty("REPRESENTANTE_LEGAL") rEPRESENTANTELEGAL("REPRESENTANTE_LEGAL"),

    @JsonProperty("PROCURADOR") pROCURADOR("PROCURADOR"),

    @JsonProperty("NAO_APLICA") nAOAPLICA("NAO_APLICA");

}

