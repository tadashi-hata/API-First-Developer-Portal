package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * Meta informações referente à API requisitada.
 * @param totalRecords Número total de registros no resultado
 * @param totalPages Número total de páginas no resultado
 * @param requestDateTime Data e hora da consulta, conforme especificação RFC-3339, formato UTC.
 */
data class Meta(

    @field:JsonProperty("totalRecords", required = true) val totalRecords: kotlin.Int,

    @field:JsonProperty("totalPages", required = true) val totalPages: kotlin.Int,

    @get:Size(max=20)
    @field:JsonProperty("requestDateTime", required = true) val requestDateTime: java.time.OffsetDateTime
) {

}

