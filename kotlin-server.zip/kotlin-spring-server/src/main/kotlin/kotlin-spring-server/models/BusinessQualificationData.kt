package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.BusinessInformedPatrimony
import kotlin-spring-server.models.BusinessQualificationDataInformedRevenue
import kotlin-spring-server.models.EconomicActivity
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * Objeto que reúne as informações relativas ao processo de qualificação. Considera-se qualificação as informações que permitam as instituições apreciar, avaliar, caracterizar e classificar o cliente com a finalidade de conhecer o seu perfil de risco e sua capacidade econômico-financeira
 * @param updateDateTime Data e hora da atualização do bloco, conforme especificação RFC-3339
 * @param economicActivities Lista dos demais códigos relativos às demais atividades econômicas da empresa, segundo padrão CNAE (Classificação Nacional de Atividades Econômicas). De preenchimento obrigatório, se houver
 * @param informedRevenue 
 * @param informedPatrimony 
 */
data class BusinessQualificationData(

    @get:Size(max=20)
    @field:JsonProperty("updateDateTime", required = true) val updateDateTime: java.time.OffsetDateTime,

    @field:Valid
    @get:Size(min=1)
    @field:JsonProperty("economicActivities", required = true) val economicActivities: kotlin.collections.List<EconomicActivity>,

    @field:Valid
    @field:JsonProperty("informedRevenue", required = true) val informedRevenue: BusinessQualificationDataInformedRevenue,

    @field:Valid
    @field:JsonProperty("informedPatrimony", required = true) val informedPatrimony: BusinessInformedPatrimony
) {

}

