package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * 
 * @param type Tipo de documento. Campo livre, de preenchimento obrigatório quando a nacionalidade for diferente de brasileira. Informar tipo e número do documento, além da, vigência e demais informações complementares para se identificar o documento de pessoa estrangeira
 * @param number Número de identificação do documento. Campo livre, de preenchimento obrigatório quando a nacionalidade for diferente de brasileira. Informar o número do documento e demais informações complementares para se identificar o documento de pessoa estrangeira
 * @param expirationDate Data de validade do documento informado, conforme especificação RFC-3339.
 * @param issueDate Data de emissão do documento, conforme especificação RFC-3339.
 * @param country Nome do país
 * @param typeAdditionalInfo Campo livre de preenchimento obrigatório se selecionada a opção OUTROS tipos de documentos.
 */
data class NationalityOtherDocument(

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=10)
    @Schema(example = "SOCIAL SEC", required = true, description = "Tipo de documento. Campo livre, de preenchimento obrigatório quando a nacionalidade for diferente de brasileira. Informar tipo e número do documento, além da, vigência e demais informações complementares para se identificar o documento de pessoa estrangeira")
    @field:JsonProperty("type", required = true) val type: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=40)
    @Schema(example = "423929299", required = true, description = "Número de identificação do documento. Campo livre, de preenchimento obrigatório quando a nacionalidade for diferente de brasileira. Informar o número do documento e demais informações complementares para se identificar o documento de pessoa estrangeira")
    @field:JsonProperty("number", required = true) val number: kotlin.String,

    @field:Valid
    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])$|^NA$")
    @get:Size(max=10)
    @Schema(example = "Fri May 21 00:00:00 UTC 2021", required = true, description = "Data de validade do documento informado, conforme especificação RFC-3339.")
    @field:JsonProperty("expirationDate", required = true) val expirationDate: java.time.LocalDate,

    @field:Valid
    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])$|^NA$")
    @get:Size(max=10)
    @Schema(example = "Fri May 21 00:00:00 UTC 2021", required = true, description = "Data de emissão do documento, conforme especificação RFC-3339.")
    @field:JsonProperty("issueDate", required = true) val issueDate: java.time.LocalDate,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=80)
    @Schema(example = "Brasil", description = "Nome do país")
    @field:JsonProperty("country") val country: kotlin.String? = null,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @Schema(example = "Informações adicionais.", description = "Campo livre de preenchimento obrigatório se selecionada a opção OUTROS tipos de documentos.")
    @field:JsonProperty("typeAdditionalInfo") val typeAdditionalInfo: kotlin.String? = null
) {

}

