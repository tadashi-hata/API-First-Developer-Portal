package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.EnumOccupationMainCodeType
import kotlin-spring-server.models.PersonalInformedPatrimony
import kotlin-spring-server.models.PersonalQualificationDataInformedIncome
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * Conjunto de informações relativas ao processo de qualificação. Considera-se qualificação as informações que permitam as instituições apreciar, avaliar, caracterizar e classificar o cliente com a finalidade de conhecer o seu perfil de risco e sua capacidade econômico-financeira
 * @param updateDateTime Data e hora da atualização do bloco, conforme especificação RFC-3339
 * @param companyCnpj Número completo do CNPJ da instituição responsável pelo Cadastro - o CNPJ corresponde ao número de inscrição no Cadastro de Pessoa Jurídica.  Deve-se ter apenas os números do CNPJ, sem máscara 
 * @param occupationCode 
 * @param occupationDescription Campo livre, de preenchimento obrigatório. Traz o código da ocupação ou o descritivo da ocupação, se selecionada a opção 'OUTRO'
 * @param informedIncome 
 * @param informedPatrimony 
 */
data class PersonalQualificationData(

    @get:Size(max=20)
    @field:JsonProperty("updateDateTime", required = true) val updateDateTime: java.time.OffsetDateTime,
    @get:Pattern(regexp="\\d{14}|^NA$")
    @get:Size(max=14)
    @field:JsonProperty("companyCnpj", required = true) val companyCnpj: kotlin.String,

    @field:Valid
    @field:JsonProperty("occupationCode", required = true) val occupationCode: EnumOccupationMainCodeType,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=100)
    @field:JsonProperty("occupationDescription", required = true) val occupationDescription: kotlin.String,

    @field:Valid
    @field:JsonProperty("informedIncome", required = true) val informedIncome: PersonalQualificationDataInformedIncome,

    @field:Valid
    @field:JsonProperty("informedPatrimony", required = true) val informedPatrimony: PersonalInformedPatrimony
) {

}

