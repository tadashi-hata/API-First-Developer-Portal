package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * 
 * @param code Código de erro específico do endpoint
 * @param title Título legível por humanos deste erro específico
 * @param detail Descrição legível por humanos deste erro específico
 */
data class ResponseErrorErrors(
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=255)
    @field:JsonProperty("code", required = true) val code: kotlin.String,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=255)
    @field:JsonProperty("title", required = true) val title: kotlin.String,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=2048)
    @field:JsonProperty("detail", required = true) val detail: kotlin.String
) {

}

