package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.BusinessPostalAddress
import kotlin-spring-server.models.CustomerEmail
import kotlin-spring-server.models.CustomerPhone
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * Conjunto de informações referentes às formas para contatar o cliente.
 * @param postalAddresses Lista de endereços da pessoa jurídica
 * @param phones Lista com telefones de contato da pessoa jurídica
 * @param emails Lista e-mails de contato
 */
data class BusinessContacts(

    @field:Valid
    @get:Size(min=1)
    @Schema(example = "null", required = true, description = "Lista de endereços da pessoa jurídica")
    @field:JsonProperty("postalAddresses", required = true) val postalAddresses: kotlin.collections.List<BusinessPostalAddress>,

    @field:Valid
    @get:Size(min=1)
    @Schema(example = "null", required = true, description = "Lista com telefones de contato da pessoa jurídica")
    @field:JsonProperty("phones", required = true) val phones: kotlin.collections.List<CustomerPhone>,

    @field:Valid
    @get:Size(min=1)
    @Schema(example = "null", required = true, description = "Lista e-mails de contato")
    @field:JsonProperty("emails", required = true) val emails: kotlin.collections.List<CustomerEmail>
) {

}

