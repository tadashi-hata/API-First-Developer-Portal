package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * 
 * @param isMain Indica se o email informado é o principal
 * @param email Endereço de email
 */
data class CustomerEmail(

    @Schema(example = "true", required = true, description = "Indica se o email informado é o principal")
    @get:JsonProperty("isMain", required = true) val isMain: kotlin.Boolean,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=320)
    @Schema(example = "karinafernandes-81@br.inter.net", required = true, description = "Endereço de email")
    @get:JsonProperty("email", required = true) val email: kotlin.String
) {

}

