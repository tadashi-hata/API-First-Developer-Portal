package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.BusinessContacts
import kotlin-spring-server.models.BusinessOtherDocument
import kotlin-spring-server.models.PartiesParticipation
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * Conjunto de informações relativas a Identificação ou seja a ação e o efeito de identificar de forma única a pessoa jurídica através de seus dados cadastrais
 * @param updateDateTime Data e hora da atualização do bloco, conforme especificação RFC-3339
 * @param businessId Um identificador único e imutável usado para identificar o recurso cliente pessoa jurídica. Este identificador não tem significado para o cliente que deu o consentimento
 * @param brandName Nome da Marca reportada pelo participante do Open Banking. O conceito a que se refere a 'marca' é em essência uma promessa da empresa em fornecer uma série específica de atributos, benefícios e serviços uniformes aos clientes 
 * @param companyName Razão social da empresa consultada é o termo registrado sob o qual uma pessoa jurídica (PJ) se individualiza e exerce suas atividades. Também pode ser chamada por denominação social ou firma empresarial
 * @param tradeName Nome fantasia da pessoa jurídica, se houver. (É o nome popular da empresa, utilizado para divulgação da empresa e melhor fixação com o público). De preenchimento obrigatório se houver
 * @param incorporationDate Data de constituição da empresa, conforme especificação RFC-3339.
 * @param cnpjNumber Número completo do CNPJ da Empresa consultada  - o CNPJ corresponde ao número de inscrição no Cadastro de Pessoa Jurídica. Deve-se ter apenas os números do CNPJ, sem máscara
 * @param companyCnpjNumber Número completo do CNPJ da instituição responsável pelo Cadastro - o CNPJ corresponde ao número de inscrição no Cadastro de Pessoa Jurídica.  Deve-se ter apenas os números do CNPJ, sem máscara 
 * @param parties Lista relativa às informações das partes envolvidas, como: sócio e /ou administrador 
 * @param contacts 
 * @param otherDocuments Relação dos demais documentos
 */
data class BusinessIdentificationData(

    @get:Size(max=20)
    @Schema(example = "2021-05-21T08:30Z", required = true, description = "Data e hora da atualização do bloco, conforme especificação RFC-3339")
    @field:JsonProperty("updateDateTime", required = true) val updateDateTime: java.time.OffsetDateTime,

    @get:Pattern(regexp="^[a-zA-Z0-9][a-zA-Z0-9\\-]{0,99}$")
    @get:Size(max=100)
    @Schema(example = "578-psd-71md6971kjh-2d414", required = true, description = "Um identificador único e imutável usado para identificar o recurso cliente pessoa jurídica. Este identificador não tem significado para o cliente que deu o consentimento")
    @field:JsonProperty("businessId", required = true) val businessId: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=80)
    @Schema(example = "Organização A", required = true, description = "Nome da Marca reportada pelo participante do Open Banking. O conceito a que se refere a 'marca' é em essência uma promessa da empresa em fornecer uma série específica de atributos, benefícios e serviços uniformes aos clientes ")
    @field:JsonProperty("brandName", required = true) val brandName: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @Schema(example = "Luiza e Benjamin Assessoria Jurídica Ltda", required = true, description = "Razão social da empresa consultada é o termo registrado sob o qual uma pessoa jurídica (PJ) se individualiza e exerce suas atividades. Também pode ser chamada por denominação social ou firma empresarial")
    @field:JsonProperty("companyName", required = true) val companyName: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @Schema(example = "Mundo da Eletronica", required = true, description = "Nome fantasia da pessoa jurídica, se houver. (É o nome popular da empresa, utilizado para divulgação da empresa e melhor fixação com o público). De preenchimento obrigatório se houver")
    @field:JsonProperty("tradeName", required = true) val tradeName: kotlin.String,

    @get:Size(max=20)
    @Schema(example = "2021-05-21T08:30Z", required = true, description = "Data de constituição da empresa, conforme especificação RFC-3339.")
    @field:JsonProperty("incorporationDate", required = true) val incorporationDate: java.time.OffsetDateTime,

    @get:Pattern(regexp="\\d{14}|^NA$")
    @get:Size(max=14)
    @Schema(example = "50685362006773", required = true, description = "Número completo do CNPJ da Empresa consultada  - o CNPJ corresponde ao número de inscrição no Cadastro de Pessoa Jurídica. Deve-se ter apenas os números do CNPJ, sem máscara")
    @field:JsonProperty("cnpjNumber", required = true) val cnpjNumber: kotlin.String,

    @Schema(example = "[\"50685362000135\",\"50685362006555\"]", required = true, description = "Número completo do CNPJ da instituição responsável pelo Cadastro - o CNPJ corresponde ao número de inscrição no Cadastro de Pessoa Jurídica.  Deve-se ter apenas os números do CNPJ, sem máscara ")
    @field:JsonProperty("companyCnpjNumber", required = true) val companyCnpjNumber: kotlin.collections.List<kotlin.String>,

    @field:Valid
    @get:Size(min=1)
    @Schema(example = "null", required = true, description = "Lista relativa às informações das partes envolvidas, como: sócio e /ou administrador ")
    @field:JsonProperty("parties", required = true) val parties: kotlin.collections.List<PartiesParticipation>,

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @field:JsonProperty("contacts", required = true) val contacts: BusinessContacts,

    @field:Valid
    @get:Size(min=1)
    @Schema(example = "null", description = "Relação dos demais documentos")
    @field:JsonProperty("otherDocuments") val otherDocuments: kotlin.collections.List<BusinessOtherDocument>? = null
) {

}

