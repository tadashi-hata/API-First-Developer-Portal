package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonValue
import kotlin-spring-server.models.EnumPartiesParticipationDocumentType
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * Lista relativa às informações das partes envolvidas, como: sócio e /ou administrador 
 * @param personType Indica se a pessoa da parte envolvida é uma pessoa natural ou juridica
 * @param type Indica o perfil de atuação na empresa. Vide Enum O administrador é o responsável por desempenhar todas as funções administrativas da empresa. É ele quem conduz o dia a dia do negócio, assinando documentos, respondendo legalmente pela sociedade, realizando empréstimos e outras ações gerenciais. Apesar de estar na linha de frente da empresa, ele é denominado sócio por também possuir sua parcela de participação no Capital Social. Sócio não tem qualquer envolvimento nas atividades administrativas da sociedade. 
 * @param civilName Nome civil completo da pessoa natural (Direito fundamental da pessoa, o nome civil é aquele atribuído à pessoa natural desde o registro de seu nascimento, com o qual será identificada por toda a sua vida, bem como após a sua morte)
 * @param socialName Nome social da pessoa natural, se houver. (aquele pelo qual travestis e transexuais se reconhecem, bem como são identificados por sua comunidade e em seu meio social, conforme Decreto Local)
 * @param companyName Razão social da empresa consultada é o termo registrado sob o qual uma pessoa jurídica (PJ) se individualiza e exerce suas atividades. Também pode ser chamada por denominação social ou firma empresarial
 * @param startDate Data de início da participação, conforme especificação RFC-3339.
 * @param shareholding Percentual de participação societária (informar com 2 casas decimais). Sócio só deve ser informado se sua participação societária for igual ou superior a 25%. p.ex: 0.25 (Este valor  representa 25%. O valor '1 'representa 100%) 
 * @param documentType 
 * @param documentNumber Número do documento informado. Campo Texto Livre para preencher número e dígito do documento se houver
 * @param documentCountry País de emissão do documento. Código do pais de acordo com o código alpha3 do ISO-3166.
 * @param documentExpirationDate Data de validade do documento informado, conforme especificação RFC-3339.
 * @param tradeName Nome fantasia da pessoa jurídica, se houver. (É o nome popular da empresa, utilizado para divulgação da empresa e melhor fixação com o público). De preenchimento obrigatório se houver
 * @param documentAdditionalInfo Campo livre, de preenchimento obrigatório quando o documento informado tiver informações complementares relevantes para a sua identificação
 * @param documentIssueDate Data de emissão do documento, conforme especificação RFC-3339.
 */
data class PartiesParticipation(

    @Schema(example = "null", required = true, description = "Indica se a pessoa da parte envolvida é uma pessoa natural ou juridica")
    @get:JsonProperty("personType", required = true) val personType: PartiesParticipation.PersonType,

    @get:Size(max=13)
    @Schema(example = "null", required = true, description = "Indica o perfil de atuação na empresa. Vide Enum O administrador é o responsável por desempenhar todas as funções administrativas da empresa. É ele quem conduz o dia a dia do negócio, assinando documentos, respondendo legalmente pela sociedade, realizando empréstimos e outras ações gerenciais. Apesar de estar na linha de frente da empresa, ele é denominado sócio por também possuir sua parcela de participação no Capital Social. Sócio não tem qualquer envolvimento nas atividades administrativas da sociedade. ")
    @get:JsonProperty("type", required = true) val type: PartiesParticipation.Type,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @Schema(example = "Juan Kaique Cláudio Fernandes", required = true, description = "Nome civil completo da pessoa natural (Direito fundamental da pessoa, o nome civil é aquele atribuído à pessoa natural desde o registro de seu nascimento, com o qual será identificada por toda a sua vida, bem como após a sua morte)")
    @get:JsonProperty("civilName", required = true) val civilName: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @Schema(example = "Karina", required = true, description = "Nome social da pessoa natural, se houver. (aquele pelo qual travestis e transexuais se reconhecem, bem como são identificados por sua comunidade e em seu meio social, conforme Decreto Local)")
    @get:JsonProperty("socialName", required = true) val socialName: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @Schema(example = "Luiza e Benjamin Assessoria Jurídica Ltda", required = true, description = "Razão social da empresa consultada é o termo registrado sob o qual uma pessoa jurídica (PJ) se individualiza e exerce suas atividades. Também pode ser chamada por denominação social ou firma empresarial")
    @get:JsonProperty("companyName", required = true) val companyName: kotlin.String,

    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])T(?:[01]\\d|2[0123]):(?:[012345]\\d):(?:[012345]\\d)Z$")
    @get:Size(max=20)
    @Schema(example = "2021-05-21T08:30Z", required = true, description = "Data de início da participação, conforme especificação RFC-3339.")
    @get:JsonProperty("startDate", required = true) val startDate: java.time.OffsetDateTime,

    @get:Pattern(regexp="^((\\d{1,9}\\.\\d{2}){1}|NA)$")
    @get:Size(max=4)
    @Schema(example = "0.51", required = true, description = "Percentual de participação societária (informar com 2 casas decimais). Sócio só deve ser informado se sua participação societária for igual ou superior a 25%. p.ex: 0.25 (Este valor  representa 25%. O valor '1 'representa 100%) ")
    @get:JsonProperty("shareholding", required = true) val shareholding: kotlin.String,

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @get:JsonProperty("documentType", required = true) val documentType: EnumPartiesParticipationDocumentType,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=20)
    @Schema(example = "73677831148", required = true, description = "Número do documento informado. Campo Texto Livre para preencher número e dígito do documento se houver")
    @get:JsonProperty("documentNumber", required = true) val documentNumber: kotlin.String,

    @get:Size(max=3)
    @Schema(example = "CAN", required = true, description = "País de emissão do documento. Código do pais de acordo com o código alpha3 do ISO-3166.")
    @get:JsonProperty("documentCountry", required = true) val documentCountry: kotlin.String,

    @field:Valid
    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])|^NA$")
    @get:Size(max=10)
    @Schema(example = "Fri May 21 00:00:00 UTC 2021", required = true, description = "Data de validade do documento informado, conforme especificação RFC-3339.")
    @get:JsonProperty("documentExpirationDate", required = true) val documentExpirationDate: java.time.LocalDate,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @Schema(example = "Mundo da Eletronica", description = "Nome fantasia da pessoa jurídica, se houver. (É o nome popular da empresa, utilizado para divulgação da empresa e melhor fixação com o público). De preenchimento obrigatório se houver")
    @get:JsonProperty("tradeName") val tradeName: kotlin.String? = null,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=100)
    @Schema(example = "CNH", description = "Campo livre, de preenchimento obrigatório quando o documento informado tiver informações complementares relevantes para a sua identificação")
    @get:JsonProperty("documentAdditionalInfo") val documentAdditionalInfo: kotlin.String? = null,

    @field:Valid
    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])$")
    @get:Size(max=10)
    @Schema(example = "Fri May 21 00:00:00 UTC 2021", description = "Data de emissão do documento, conforme especificação RFC-3339.")
    @get:JsonProperty("documentIssueDate") val documentIssueDate: java.time.LocalDate? = null
) {

    /**
    * Indica se a pessoa da parte envolvida é uma pessoa natural ou juridica
    * Values: nATURAL,jURIDICA
    */
    enum class PersonType(val value: kotlin.String) {

        @JsonProperty("PESSOA_NATURAL") nATURAL("PESSOA_NATURAL"),
        @JsonProperty("PESSOA_JURIDICA") jURIDICA("PESSOA_JURIDICA")
    }

    /**
    * Indica o perfil de atuação na empresa. Vide Enum O administrador é o responsável por desempenhar todas as funções administrativas da empresa. É ele quem conduz o dia a dia do negócio, assinando documentos, respondendo legalmente pela sociedade, realizando empréstimos e outras ações gerenciais. Apesar de estar na linha de frente da empresa, ele é denominado sócio por também possuir sua parcela de participação no Capital Social. Sócio não tem qualquer envolvimento nas atividades administrativas da sociedade. 
    * Values: sOCIO,aDMINISTRADOR
    */
    enum class Type(val value: kotlin.String) {

        @JsonProperty("SOCIO") sOCIO("SOCIO"),
        @JsonProperty("ADMINISTRADOR") aDMINISTRADOR("ADMINISTRADOR")
    }

}

