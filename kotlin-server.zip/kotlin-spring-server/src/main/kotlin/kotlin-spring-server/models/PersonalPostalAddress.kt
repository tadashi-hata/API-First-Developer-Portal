package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.EnumCountrySubDivision
import kotlin-spring-server.models.GeographicCoordinates
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * 
 * @param isMain Indica se o endereço informado é o principal.
 * @param address Corresponde ao endereço residencial do cliente.
 * @param districtName Bairro é uma comunidade ou região localizada em uma cidade ou município de acordo com as suas subdivisões geográficas.
 * @param townName Localidade: O nome da localidade corresponde à designação da cidade ou município no qual o endereço está localizado. 
 * @param countrySubDivision 
 * @param postCode Código de Endereçamento Postal: Composto por um conjunto numérico de oito dígitos, o objetivo principal do CEP é orientar e acelerar o encaminhamento, o tratamento e a entrega de objetos postados nos Correios, por meio da sua atribuição a localidades, logradouros, unidades dos Correios, serviços, órgãos públicos, empresas e edifícios. p.ex. '01311000'. 
 * @param country Nome do país
 * @param additionalInfo Alguns logradouros ainda necessitam ser especificados por meio de complemento.
 * @param ibgeTownCode Código IBGE de Município. A Tabela de Códigos de Municípios do IBGE apresenta a lista dos municípios brasileiros associados a um código composto de 7 dígitos, sendo os dois primeiros referentes ao código da Unidade da Federação.
 * @param countryCode Código do pais de acordo com o código “alpha3” do ISO-3166.
 * @param geographicCoordinates 
 */
data class PersonalPostalAddress(

    @field:JsonProperty("isMain", required = true) val isMain: kotlin.Boolean,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=150)
    @field:JsonProperty("address", required = true) val address: kotlin.String,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=50)
    @field:JsonProperty("districtName", required = true) val districtName: kotlin.String,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=50)
    @field:JsonProperty("townName", required = true) val townName: kotlin.String,

    @field:Valid
    @field:JsonProperty("countrySubDivision", required = true) val countrySubDivision: EnumCountrySubDivision,
    @get:Pattern(regexp="\\d{8}|^NA$")
    @get:Size(max=8)
    @field:JsonProperty("postCode", required = true) val postCode: kotlin.String,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=80)
    @field:JsonProperty("country", required = true) val country: kotlin.String,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=30)
    @field:JsonProperty("additionalInfo") val additionalInfo: kotlin.String? = null,
    @get:Pattern(regexp="\\d{7}$")
    @get:Size(max=7)
    @field:JsonProperty("ibgeTownCode") val ibgeTownCode: kotlin.String? = null,

    @get:Size(max=3)
    @field:JsonProperty("countryCode") val countryCode: kotlin.String? = null,

    @field:Valid
    @field:JsonProperty("geographicCoordinates") val geographicCoordinates: GeographicCoordinates? = null
) {

}

