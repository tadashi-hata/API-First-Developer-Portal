package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * 
 * @param amount Valor do patrimônio informado. Expresso em valor monetário com 4 casas decimais. Patrimônio é o conjunto de bens vinculado a uma pessoa ou a uma entidade. 
 * @param currency Moeda referente ao valor do patrimônio, segundo modelo ISO-4217.
 * @param date Data de referência do Patrimônio, conforme especificação RFC-3339.
 */
data class BusinessInformedPatrimony(

    @field:JsonProperty("amount", required = true) val amount: kotlin.Double,
    @get:Pattern(regexp="^(\\w{3}){1}$|^NA$")
    @get:Size(max=3)
    @field:JsonProperty("currency", required = true) val currency: kotlin.String,

    @field:Valid    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])$|^NA$")
    @get:Size(max=20)
    @field:JsonProperty("date", required = true) val date: java.time.LocalDate
) {

}

