package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.EnumMaritalStatusCode
import kotlin-spring-server.models.EnumSex
import kotlin-spring-server.models.Nationality
import kotlin-spring-server.models.PersonalContacts
import kotlin-spring-server.models.PersonalDocument
import kotlin-spring-server.models.PersonalIdentificationDataFiliationInner
import kotlin-spring-server.models.PersonalOtherDocument
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * Conjunto de informações relativas a Identificação ou seja a ação e o efeito de identificar de forma única a pessoa natural através de seus dados cadastrais.
 * @param updateDateTime 
 * @param personalId Um identificador único e imutável usado para identificar o recurso cliente pessoa natural. Este identificador não tem significado para o cliente que deu o consentimento
 * @param brandName Nome da Marca reportada pelo participante do Open Banking. O conceito a que se refere a 'marca' é em essência uma promessa da empresa em fornecer uma série específica de atributos, benefícios e serviços uniformes aos clientes
 * @param civilName Nome civil completo da pessoa natural (Direito fundamental da pessoa, o nome civil é aquele atribuído à pessoa natural desde o registro de seu nascimento, com o qual será identificada por toda a sua vida, bem como após a sua morte)
 * @param socialName Nome social da pessoa natural, se houver. (aquele pelo qual travestis e transexuais se reconhecem, bem como são identificados por sua comunidade e em seu meio social, conforme Decreto Local)
 * @param birthDate Data de nascimento, conforme especificação RFC-3339
 * @param maritalStatusCode 
 * @param sex 
 * @param companyCnpj Número completo do CNPJ da instituição responsável pelo Cadastro - o CNPJ corresponde ao número de inscrição no Cadastro de Pessoa Jurídica.  Deve-se ter apenas os números do CNPJ, sem máscara 
 * @param documents 
 * @param otherDocuments Relação dos demais documentos
 * @param hasBrazilianNationality Informa se o Cliente tem nacionalidade brasileira.
 * @param nationality 
 * @param filiation 
 * @param contacts 
 * @param maritalStatusAdditionalInfo Campo livre para complementar a informação relativa ao estado marital, quando selecionada a opção 'OUTROS'
 */
data class PersonalIdentificationData(

    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])T(?:[01]\\d|2[0123]):(?:[012345]\\d):(?:[012345]\\d)Z$")
    @get:Size(max=20)
    @Schema(example = "2021-05-21T08:30Z", required = true, description = "")
    @field:JsonProperty("updateDateTime", required = true) val updateDateTime: java.time.OffsetDateTime,

    @get:Pattern(regexp="^[a-zA-Z0-9][a-zA-Z0-9\\-]{0,99}$")
    @get:Size(max=100)
    @Schema(example = "578-psd-71md6971kjh-2d414", required = true, description = "Um identificador único e imutável usado para identificar o recurso cliente pessoa natural. Este identificador não tem significado para o cliente que deu o consentimento")
    @field:JsonProperty("personalId", required = true) val personalId: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=80)
    @Schema(example = "Organização A", required = true, description = "Nome da Marca reportada pelo participante do Open Banking. O conceito a que se refere a 'marca' é em essência uma promessa da empresa em fornecer uma série específica de atributos, benefícios e serviços uniformes aos clientes")
    @field:JsonProperty("brandName", required = true) val brandName: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @Schema(example = "Juan Kaique Cláudio Fernandes", required = true, description = "Nome civil completo da pessoa natural (Direito fundamental da pessoa, o nome civil é aquele atribuído à pessoa natural desde o registro de seu nascimento, com o qual será identificada por toda a sua vida, bem como após a sua morte)")
    @field:JsonProperty("civilName", required = true) val civilName: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @Schema(example = "Jaqueline de Freitas", required = true, description = "Nome social da pessoa natural, se houver. (aquele pelo qual travestis e transexuais se reconhecem, bem como são identificados por sua comunidade e em seu meio social, conforme Decreto Local)")
    @field:JsonProperty("socialName", required = true) val socialName: kotlin.String,

    @field:Valid
    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])$")
    @get:Size(max=10)
    @Schema(example = "Fri May 21 00:00:00 UTC 2021", required = true, description = "Data de nascimento, conforme especificação RFC-3339")
    @field:JsonProperty("birthDate", required = true) val birthDate: java.time.LocalDate,

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @field:JsonProperty("maritalStatusCode", required = true) val maritalStatusCode: EnumMaritalStatusCode,

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @field:JsonProperty("sex", required = true) val sex: EnumSex,

    @Schema(example = "[\"01773247000103\",\"01773247000563\"]", required = true, description = "Número completo do CNPJ da instituição responsável pelo Cadastro - o CNPJ corresponde ao número de inscrição no Cadastro de Pessoa Jurídica.  Deve-se ter apenas os números do CNPJ, sem máscara ")
    @field:JsonProperty("companyCnpj", required = true) val companyCnpj: kotlin.collections.List<kotlin.String>,

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @field:JsonProperty("documents", required = true) val documents: PersonalDocument,

    @field:Valid
    @get:Size(min=1)
    @Schema(example = "null", required = true, description = "Relação dos demais documentos")
    @field:JsonProperty("otherDocuments", required = true) val otherDocuments: kotlin.collections.List<PersonalOtherDocument>,

    @Schema(example = "false", required = true, description = "Informa se o Cliente tem nacionalidade brasileira.")
    @field:JsonProperty("hasBrazilianNationality", required = true) val hasBrazilianNationality: kotlin.Boolean,

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @field:JsonProperty("nationality", required = true) val nationality: kotlin.collections.List<Nationality>,

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @field:JsonProperty("filiation", required = true) val filiation: kotlin.collections.List<PersonalIdentificationDataFiliationInner>,

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @field:JsonProperty("contacts", required = true) val contacts: PersonalContacts,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=50)
    @Schema(example = "Casado", description = "Campo livre para complementar a informação relativa ao estado marital, quando selecionada a opção 'OUTROS'")
    @field:JsonProperty("maritalStatusAdditionalInfo") val maritalStatusAdditionalInfo: kotlin.String? = null
) {

}

