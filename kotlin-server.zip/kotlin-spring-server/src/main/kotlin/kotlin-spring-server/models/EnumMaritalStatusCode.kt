package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonValue
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
* Estado marital do cliente.  
* Values: sOLTEIRO,cASADO,vIUVO,sEPARADOJUDICIALMENTE,dIVORCIADO,uNIAOESTAVEL,oUTRO
*/
enum class EnumMaritalStatusCode(val value: kotlin.String) {

    @JsonProperty("SOLTEIRO") sOLTEIRO("SOLTEIRO"),
    @JsonProperty("CASADO") cASADO("CASADO"),
    @JsonProperty("VIUVO") vIUVO("VIUVO"),
    @JsonProperty("SEPARADO_JUDICIALMENTE") sEPARADOJUDICIALMENTE("SEPARADO_JUDICIALMENTE"),
    @JsonProperty("DIVORCIADO") dIVORCIADO("DIVORCIADO"),
    @JsonProperty("UNIAO_ESTAVEL") uNIAOESTAVEL("UNIAO_ESTAVEL"),
    @JsonProperty("OUTRO") oUTRO("OUTRO")
}

