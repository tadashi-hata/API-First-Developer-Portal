package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * Conjunto de informações, que correspondem aos valores das coordenadas geográficas em graus decimais, no Sistema de referência WGS84
 * @param latitude Informação da Latitude referente a geolocalização informada. Entre -90 e 90.p.ex. '-90.8365180'. (2 casas antes da vírgula, 11 posições)  
 * @param longitude Informação da Longitude referente a geolocalização informada. Entre -180 e 180. p.ex '-180.836519.' (3 casas antes da vírgula, 11 posições)  
 */
data class GeographicCoordinates(

    @get:Pattern(regexp="^-?\\d{1,2}\\.\\d{1,9}$")
    @get:Size(max=13)
    @Schema(example = "-90.8365180", description = "Informação da Latitude referente a geolocalização informada. Entre -90 e 90.p.ex. '-90.8365180'. (2 casas antes da vírgula, 11 posições)  ")
    @get:JsonProperty("latitude") val latitude: kotlin.String? = null,

    @get:Pattern(regexp="^-?\\d{1,3}\\.\\d{1,8}$")
    @get:Size(max=13)
    @Schema(example = "-180.836519", description = "Informação da Longitude referente a geolocalização informada. Entre -180 e 180. p.ex '-180.836519.' (3 casas antes da vírgula, 11 posições)  ")
    @get:JsonProperty("longitude") val longitude: kotlin.String? = null
) {

}

