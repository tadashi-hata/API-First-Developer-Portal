package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * Objeto agrupador de informações relativas a Documentos da pessoa natural
 * @param cpfNumber Número completo do CPF. Atributo que corresponde às informações mínimas exigidas pela Regulamentação em vigor. O CPF é o Cadastro de Pessoa natural.  Ele é um documento feito pela Receita Federal e serve para identificar os contribuintes. O CPF é uma numeração com 11 dígitos, que só mudam por decisão judicial. O documento é emitido pela receita federal
 * @param passportNumber Número do Passaporte. Documento concedido aos viajantes por uma autoridade administrativa nacional a fim de certificar sua identidade perante autoridades estrangeiras. De preenchimento obrigatório. Aplicável somente à Pessoa natural residente no exterior desobrigada de inscrição no CPF. 
 * @param passportCountry Pais de emissão do passaporte. Código do pais de acordo com o código 'alpha3' do ISO-3166.
 * @param passportExpirationDate Data vigência do Passaporte, conforme especificação RFC-3339.
 * @param passportIssueDate Data de emissão do passaporte, conforme especificação RFC-3339.
 */
data class PersonalDocument(
    @get:Pattern(regexp="^\\d{11}$|^NA$")
    @get:Size(max=11)
    @field:JsonProperty("cpfNumber", required = true) val cpfNumber: kotlin.String,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=20)
    @field:JsonProperty("passportNumber", required = true) val passportNumber: kotlin.String,
    @get:Pattern(regexp="^(\\w{3}){1}$|^NA$")
    @get:Size(max=3)
    @field:JsonProperty("passportCountry", required = true) val passportCountry: kotlin.String,

    @field:Valid    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])$|^NA$")
    @get:Size(max=10)
    @field:JsonProperty("passportExpirationDate", required = true) val passportExpirationDate: java.time.LocalDate,

    @field:Valid    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])$|^NA$")
    @get:Size(max=10)
    @field:JsonProperty("passportIssueDate") val passportIssueDate: java.time.LocalDate? = null
) {

}

