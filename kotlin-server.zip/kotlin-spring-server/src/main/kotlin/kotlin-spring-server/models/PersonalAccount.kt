package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonValue
import kotlin-spring-server.models.Type
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * Lista de contas depósito à vista, poupança e pagamento pré-pagas mantidas pelo cliente na instituição transmissora e para as quais ele tenha fornecido consentimento 
 * @param compeCode Código identificador atribuído pelo Banco Central do Brasil às instituições participantes do STR (Sistema de Transferência de reservas).O Compe (Sistema de Compensação de Cheques e Outros Papéis) é um sistema que identifica e processa as compensações bancárias. Ele é representado por um código de três dígitos que serve como identificador de bancos, sendo assim, cada instituição bancária possui um número exclusivo
 * @param branchCode Código da Agência detentora da conta. (Agência é a dependência destinada ao atendimento aos clientes, ao público em geral e aos associados de cooperativas de crédito, no exercício de atividades da instituição, não podendo ser móvel ou transitória) 
 * @param number Número da conta 
 * @param checkDigit Dígito da conta 
 * @param type 
 * @param subtype Subtipo de conta (vide Enum):  Conta individual - possui um único titular Conta conjunta simples - onde as movimentações financeiras só podem serem realizadas mediante autorização de TODOS os correntistas da conta. Conta conjunta solidária - é a modalidade cujos titulares podem realizar movimentações de forma isolada, isto é, sem que seja necessária a autorização dos demais titulares. SEM_SUB_TIPO_CONTA - para reporte nos dados de identificação quando o cliente não possuir conta na instituição transmissora. 
 */
data class PersonalAccount(

    @get:Pattern(regexp="\\d{3}|^NA$")
    @get:Size(max=3)
    @Schema(example = "001", required = true, description = "Código identificador atribuído pelo Banco Central do Brasil às instituições participantes do STR (Sistema de Transferência de reservas).O Compe (Sistema de Compensação de Cheques e Outros Papéis) é um sistema que identifica e processa as compensações bancárias. Ele é representado por um código de três dígitos que serve como identificador de bancos, sendo assim, cada instituição bancária possui um número exclusivo")
    @field:JsonProperty("compeCode", required = true) val compeCode: kotlin.String,

    @get:Pattern(regexp="\\d{4}|^NA$")
    @get:Size(max=4)
    @Schema(example = "6272", required = true, description = "Código da Agência detentora da conta. (Agência é a dependência destinada ao atendimento aos clientes, ao público em geral e aos associados de cooperativas de crédito, no exercício de atividades da instituição, não podendo ser móvel ou transitória) ")
    @field:JsonProperty("branchCode", required = true) val branchCode: kotlin.String,

    @get:Pattern(regexp="^\\d{8,20}$|^NA$")
    @get:Size(max=20)
    @Schema(example = "24550245", required = true, description = "Número da conta ")
    @field:JsonProperty("number", required = true) val number: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=1)
    @Schema(example = "4", required = true, description = "Dígito da conta ")
    @field:JsonProperty("checkDigit", required = true) val checkDigit: kotlin.String,

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @field:JsonProperty("type", required = true) val type: Type,

    @Schema(example = "INDIVIDUAL", required = true, description = "Subtipo de conta (vide Enum):  Conta individual - possui um único titular Conta conjunta simples - onde as movimentações financeiras só podem serem realizadas mediante autorização de TODOS os correntistas da conta. Conta conjunta solidária - é a modalidade cujos titulares podem realizar movimentações de forma isolada, isto é, sem que seja necessária a autorização dos demais titulares. SEM_SUB_TIPO_CONTA - para reporte nos dados de identificação quando o cliente não possuir conta na instituição transmissora. ")
    @field:JsonProperty("subtype", required = true) val subtype: PersonalAccount.Subtype
) {

    /**
    * Subtipo de conta (vide Enum):  Conta individual - possui um único titular Conta conjunta simples - onde as movimentações financeiras só podem serem realizadas mediante autorização de TODOS os correntistas da conta. Conta conjunta solidária - é a modalidade cujos titulares podem realizar movimentações de forma isolada, isto é, sem que seja necessária a autorização dos demais titulares. SEM_SUB_TIPO_CONTA - para reporte nos dados de identificação quando o cliente não possuir conta na instituição transmissora. 
    * Values: iNDIVIDUAL,cONJUNTASIMPLES,cONJUNTASOLIDARIA,sEMSUBTIPOCONTA
    */
    enum class Subtype(val value: kotlin.String) {

        @JsonProperty("INDIVIDUAL") iNDIVIDUAL("INDIVIDUAL"),
        @JsonProperty("CONJUNTA_SIMPLES") cONJUNTASIMPLES("CONJUNTA_SIMPLES"),
        @JsonProperty("CONJUNTA_SOLIDARIA") cONJUNTASOLIDARIA("CONJUNTA_SOLIDARIA"),
        @JsonProperty("SEM_SUB_TIPO_CONTA") sEMSUBTIPOCONTA("SEM_SUB_TIPO_CONTA")
    }

}

