package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.EnumProcuratorsTypePersonal
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * 
 * @param type 
 * @param cpfNumber Número completo do CPF. O CPF é o Cadastro de Pessoa natural. Ele é um documento feito pela Receita Federal e serve para identificar os contribuintes. O CPF é uma numeração com 11 dígitos, que só mudam por decisão judicial. O documento é emitido pela receita federal
 * @param civilName Nome civil completo da pessoa natural. (Direito fundamental da pessoa, o nome civil é aquele atribuído à pessoa natural desde o registro de seu nascimento, com o qual será identificada por toda a sua vida, bem como após a sua morte)
 * @param socialName Nome social da pessoa natural, se houver. (aquele pelo qual travestis e transexuais se reconhecem, bem como são identificados por sua comunidade e em seu meio social, conforme Decreto Nº 51.180, de 14 de janeiro de 2010)
 */
data class PersonalProcurator(

    @field:Valid
    @field:JsonProperty("type", required = true) val type: EnumProcuratorsTypePersonal,
    @get:Pattern(regexp="^\\d{11}$|^NA$")
    @get:Size(max=11)
    @field:JsonProperty("cpfNumber", required = true) val cpfNumber: kotlin.String,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @field:JsonProperty("civilName", required = true) val civilName: kotlin.String,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @field:JsonProperty("socialName", required = true) val socialName: kotlin.String
) {

}

