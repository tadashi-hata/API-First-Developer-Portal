package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * 
 * @param number Número do outro documento. De preenchimento obrigatório, para a Pessoa jurídica com domicílio ou sede no exterior, desobrigada de inscrição no CNPJ
 * @param country Pais de emissão do tipo de documento informado. Código do pais de acordo com o código “alpha3” do ISO-3166
 * @param expirationDate Data vigência do tipo de  documento informado, conforme especificação RFC-3339.
 * @param type Número do Tipo de documento informado. De preenchimento obrigatório, para a Pessoa jurídica com domicílio ou sede no exterior, desobrigada de inscrição no CNPJ
 */
data class BusinessOtherDocument(
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=20)
    @field:JsonProperty("number", required = true) val number: kotlin.String,
    @get:Pattern(regexp="^(\\w{3}){1}$|^NA$")
    @get:Size(max=3)
    @field:JsonProperty("country", required = true) val country: kotlin.String,

    @field:Valid    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])$|^NA$")
    @get:Size(max=10)
    @field:JsonProperty("expirationDate", required = true) val expirationDate: java.time.LocalDate,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=20)
    @field:JsonProperty("type") val type: kotlin.String? = null
) {

}

