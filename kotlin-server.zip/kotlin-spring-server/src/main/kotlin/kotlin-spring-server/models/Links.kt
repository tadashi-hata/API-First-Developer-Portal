package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * Referências para outros recusos da API requisitada.
 * @param self URI completo que gerou a resposta atual.
 * @param first URI da primeira página que originou essa lista de resultados. Restrição - Obrigatório quando não for a primeira página da resposta
 * @param prev URI da página anterior dessa lista de resultados. Restrição -  Obrigatório quando não for a primeira página da resposta
 * @param next URI da próxima página dessa lista de resultados. Restrição - Obrigatório quando não for a última página da resposta
 * @param last URI da última página dessa lista de resultados. Restrição - Obrigatório quando não for a última página da resposta
 */
data class Links(

    @field:Valid
    @get:Pattern(regexp="^(https?://)?(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,6}\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)$")
    @get:Size(max=2000)
    @Schema(example = "https://api.banco.com.br/open-banking/api/v1/resource", required = true, description = "URI completo que gerou a resposta atual.")
    @get:JsonProperty("self", required = true) val self: java.net.URI,

    @field:Valid
    @get:Pattern(regexp="^(https?://)?(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,6}\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)$")
    @get:Size(max=2000)
    @Schema(example = "https://api.banco.com.br/open-banking/api/v1/resource", description = "URI da primeira página que originou essa lista de resultados. Restrição - Obrigatório quando não for a primeira página da resposta")
    @get:JsonProperty("first") val first: java.net.URI? = null,

    @field:Valid
    @get:Pattern(regexp="^(https?://)?(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,6}\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)$")
    @get:Size(max=2000)
    @Schema(example = "https://api.banco.com.br/open-banking/api/v1/resource", description = "URI da página anterior dessa lista de resultados. Restrição -  Obrigatório quando não for a primeira página da resposta")
    @get:JsonProperty("prev") val prev: java.net.URI? = null,

    @field:Valid
    @get:Pattern(regexp="^(https?://)?(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,6}\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)$")
    @get:Size(max=2000)
    @Schema(example = "https://api.banco.com.br/open-banking/api/v1/resource", description = "URI da próxima página dessa lista de resultados. Restrição - Obrigatório quando não for a última página da resposta")
    @get:JsonProperty("next") val next: java.net.URI? = null,

    @field:Valid
    @get:Pattern(regexp="^(https?://)?(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,6}\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)$")
    @get:Size(max=2000)
    @Schema(example = "https://api.banco.com.br/open-banking/api/v1/resource", description = "URI da última página dessa lista de resultados. Restrição - Obrigatório quando não for a última página da resposta")
    @get:JsonProperty("last") val last: java.net.URI? = null
) {

}

