package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.EnumAreaCode
import kotlin-spring-server.models.EnumCustomerPhoneType
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * 
 * @param isMain Indica se o telefone informado é o principal
 * @param type 
 * @param countryCallingCode Número de DDI (Discagem Direta Internacional) para telefone de acesso ao Cliente - se houver
 * @param areaCode 
 * @param number Número de telefone do cliente
 * @param phoneExtension Número do ramal. De preenchimento obrigatório se fizer parte da identificação do número do telefone informado
 * @param additionalInfo Informação complementar relativa ao tipo de telefone selecionado. [Restrição] De preenchimento obrigatório quando selecionado o tipo 'OUTRO'.
 */
data class CustomerPhone(

    @Schema(example = "true", required = true, description = "Indica se o telefone informado é o principal")
    @field:JsonProperty("isMain", required = true) val isMain: kotlin.Boolean,

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @field:JsonProperty("type", required = true) val type: EnumCustomerPhoneType,

    @get:Pattern(regexp="^\\d{2,4}$|^NA$")
    @get:Size(max=4)
    @Schema(example = "55", required = true, description = "Número de DDI (Discagem Direta Internacional) para telefone de acesso ao Cliente - se houver")
    @field:JsonProperty("countryCallingCode", required = true) val countryCallingCode: kotlin.String,

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @field:JsonProperty("areaCode", required = true) val areaCode: EnumAreaCode,

    @get:Pattern(regexp="^([0-9]{8,11})|^NA$")
    @get:Size(max=11)
    @Schema(example = "29875132", required = true, description = "Número de telefone do cliente")
    @field:JsonProperty("number", required = true) val number: kotlin.String,

    @get:Pattern(regexp="^\\d{1,5}$|^NA$")
    @get:Size(max=5)
    @Schema(example = "932", required = true, description = "Número do ramal. De preenchimento obrigatório se fizer parte da identificação do número do telefone informado")
    @field:JsonProperty("phoneExtension", required = true) val phoneExtension: kotlin.String,

    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @Schema(example = "Informações adicionais.", description = "Informação complementar relativa ao tipo de telefone selecionado. [Restrição] De preenchimento obrigatório quando selecionado o tipo 'OUTRO'.")
    @field:JsonProperty("additionalInfo") val additionalInfo: kotlin.String? = null
) {

}

