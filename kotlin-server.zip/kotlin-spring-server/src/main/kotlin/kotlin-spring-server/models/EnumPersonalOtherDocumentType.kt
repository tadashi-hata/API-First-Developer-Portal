package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
* Relação dos Códigos dos demais documentos pessoa natural. 
* Values: cNH,rG,nIF,rNE,oUTROS,sEMOUTROSDOCUMENTOS
*/
enum class EnumPersonalOtherDocumentType(val value: kotlin.String) {

    @JsonProperty("CNH") cNH("CNH"),

    @JsonProperty("RG") rG("RG"),

    @JsonProperty("NIF") nIF("NIF"),

    @JsonProperty("RNE") rNE("RNE"),

    @JsonProperty("OUTROS") oUTROS("OUTROS"),

    @JsonProperty("SEM_OUTROS_DOCUMENTOS") sEMOUTROSDOCUMENTOS("SEM_OUTROS_DOCUMENTOS");

}

