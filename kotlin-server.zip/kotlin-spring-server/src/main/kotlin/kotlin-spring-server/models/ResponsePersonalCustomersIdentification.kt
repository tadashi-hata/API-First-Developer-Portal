package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.Links
import kotlin-spring-server.models.Meta
import kotlin-spring-server.models.PersonalIdentificationData
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * 
 * @param &#x60;data&#x60; 
 * @param links 
 * @param meta 
 */
data class ResponsePersonalCustomersIdentification(

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @get:JsonProperty("data", required = true) val `data`: kotlin.collections.List<PersonalIdentificationData>,

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @get:JsonProperty("links", required = true) val links: Links,

    @field:Valid
    @Schema(example = "null", required = true, description = "")
    @get:JsonProperty("meta", required = true) val meta: Meta
) {

}

