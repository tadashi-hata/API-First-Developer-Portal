package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonValue
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * 
 * @param compeCode Código identificador atribuído pelo Banco Central do Brasil às instituições participantes do STR (Sistema de Transferência de reservas).O Compe (Sistema de Compensação de Cheques e Outros Papéis) é um sistema que identifica e processa as compensações bancárias. Ele é representado por um código de três dígitos que serve como identificador de bancos, sendo assim, cada instituição bancária possui um número exclusivo
 * @param branchCode Código da Agência detentora da conta. (Agência é a dependência destinada ao atendimento aos clientes, ao público em geral e aos associados de cooperativas de crédito, no exercício de atividades da instituição, não podendo ser móvel ou transitória) 
 * @param number Número da conta 
 * @param checkDigit Dígito da conta 
 * @param type Tipos de contas. Modalidades tradicionais previstas pela Resolução 4.753, não contemplando contas vinculadas, conta de domiciliados no exterior, contas em moedas estrangeiras e conta correspondente moeda eletrônica. Vide Enum Conta de depósito à vista ou Conta corrente - é o tipo mais comum. Nela, o dinheiro fica à sua disposição para ser sacado a qualquer momento. Essa conta não gera rendimentos para o depositante Conta poupança - foi criada para estimular as pessoas a pouparem. O dinheiro que ficar na conta por trinta dias passa a gerar rendimentos, com isenção de imposto de renda para quem declara. Ou seja, o dinheiro “cresce” (rende) enquanto ficar guardado na conta. Cada depósito terá rendimentos de mês em mês, sempre no dia do mês em que o dinheiro tiver sido depositado Conta de pagamento pré-paga: segundo CIRCULAR Nº 3.680, BCB de  2013, é a 'destinada à execução de transações de pagamento em moeda eletrônica realizadas com base em fundos denominados em reais previamente aportados'. SEM_TIPO_CONTA - para reporte nos dados de identificação quando o cliente não possuir conta na instituição transmissora. 
 */
data class BusinessAccount(
    @get:Pattern(regexp="\\d{3}|^NA$")
    @get:Size(max=3)
    @field:JsonProperty("compeCode", required = true) val compeCode: kotlin.String,
    @get:Pattern(regexp="\\d{4}|^NA$")
    @get:Size(max=4)
    @field:JsonProperty("branchCode", required = true) val branchCode: kotlin.String,
    @get:Pattern(regexp="^\\d{8,20}$|^NA$")
    @get:Size(max=20)
    @field:JsonProperty("number", required = true) val number: kotlin.String,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=1)
    @field:JsonProperty("checkDigit", required = true) val checkDigit: kotlin.String,

    @field:JsonProperty("type", required = true) val type: BusinessAccount.Type
) {

    /**
    * Tipos de contas. Modalidades tradicionais previstas pela Resolução 4.753, não contemplando contas vinculadas, conta de domiciliados no exterior, contas em moedas estrangeiras e conta correspondente moeda eletrônica. Vide Enum Conta de depósito à vista ou Conta corrente - é o tipo mais comum. Nela, o dinheiro fica à sua disposição para ser sacado a qualquer momento. Essa conta não gera rendimentos para o depositante Conta poupança - foi criada para estimular as pessoas a pouparem. O dinheiro que ficar na conta por trinta dias passa a gerar rendimentos, com isenção de imposto de renda para quem declara. Ou seja, o dinheiro “cresce” (rende) enquanto ficar guardado na conta. Cada depósito terá rendimentos de mês em mês, sempre no dia do mês em que o dinheiro tiver sido depositado Conta de pagamento pré-paga: segundo CIRCULAR Nº 3.680, BCB de  2013, é a 'destinada à execução de transações de pagamento em moeda eletrônica realizadas com base em fundos denominados em reais previamente aportados'. SEM_TIPO_CONTA - para reporte nos dados de identificação quando o cliente não possuir conta na instituição transmissora. 
    * Values: cONTADEPOSITOAVISTA,cONTAPOUPANCA,cONTAPAGAMENTOPREPAGA,sEMTIPOCONTA
    */
    enum class Type(val value: kotlin.String) {
    
        @JsonProperty("CONTA_DEPOSITO_A_VISTA") cONTADEPOSITOAVISTA("CONTA_DEPOSITO_A_VISTA"),
    
        @JsonProperty("CONTA_POUPANCA") cONTAPOUPANCA("CONTA_POUPANCA"),
    
        @JsonProperty("CONTA_PAGAMENTO_PRE_PAGA") cONTAPAGAMENTOPREPAGA("CONTA_PAGAMENTO_PRE_PAGA"),
    
        @JsonProperty("SEM_TIPO_CONTA") sEMTIPOCONTA("SEM_TIPO_CONTA");
    
    }

}

