package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.NationalityOtherDocument
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * Objeto que agrupa informações relativas à nacionalidade da Pessoa Natural
 * @param otherNationalitiesInfo Campo de preenchimento obrigatório caso o cliente não possua nacionalidade brasileira. Preencher indicando todas suas demais nacionalidades utilizando o código de pais de acordo com o código “alpha3” do ISO-3166.p.ex.'CAN' 
 * @param documents Lista que traz relação de documentos complementares de pessoas com nacionalidade diferente de brasileira
 */
data class Nationality(

    @get:Size(max=40)
    @field:JsonProperty("otherNationalitiesInfo", required = true) val otherNationalitiesInfo: kotlin.String,

    @field:Valid
    @field:JsonProperty("documents", required = true) val documents: kotlin.collections.List<NationalityOtherDocument>
) {

}

