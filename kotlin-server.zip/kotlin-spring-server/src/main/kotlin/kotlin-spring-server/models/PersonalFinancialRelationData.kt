package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import kotlin-spring-server.models.EnumProductServiceType
import kotlin-spring-server.models.PersonalAccount
import kotlin-spring-server.models.PersonalProcurator
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * Objeto que reúne as informações relativas ao relacionamento do cliente junto à Instituição. Considera-se relacionamento as informações que permitam conhecer desde quando a pessoa consultada é cliente da instituição, bem como um indicador dos produtos e serviços que ela consome atualmente e seus representantes
 * @param updateDateTime Data e hora da atualização do bloco de Relacionamento, conforme especificação RFC-3339, formato UTC.
 * @param startDate Data de início de relacionamento com a Instituição Financeira. Deve trazer o menor valor entre a informação reportada ao BACEN pelo DOC 3040 e CCS.
 * @param productsServicesType 
 * @param procurators Lista dos representantes. De preenchimento obrigatório se houver representante.
 * @param accounts Lista de contas depósito à vista, poupança e pagamento pré-pagas mantidas pelo cliente na instituição transmissora.     
 * @param productsServicesTypeAdditionalInfo Informações adicionais do tipo de serviço. [Restrição] Campo obrigatório quando productsServicesType for 'OUTROS'. 
 */
data class PersonalFinancialRelationData(
    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])T(?:[01]\\d|2[0123]):(?:[012345]\\d):(?:[012345]\\d)Z$")
    @get:Size(max=20)
    @field:JsonProperty("updateDateTime", required = true) val updateDateTime: java.time.OffsetDateTime,
    @get:Pattern(regexp="^(\\d{4})-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])T(?:[01]\\d|2[0123]):(?:[012345]\\d):(?:[012345]\\d)Z$")
    @get:Size(max=20)
    @field:JsonProperty("startDate", required = true) val startDate: java.time.OffsetDateTime,

    @field:Valid
    @get:Size(min=1,max=12) 
    @field:JsonProperty("productsServicesType", required = true) val productsServicesType: kotlin.collections.List<EnumProductServiceType>,

    @field:Valid
    @get:Size(min=1)
    @field:JsonProperty("procurators", required = true) val procurators: kotlin.collections.List<PersonalProcurator>,

    @field:Valid
    @get:Size(min=1)
    @field:JsonProperty("accounts", required = true) val accounts: kotlin.collections.List<PersonalAccount>,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=100)
    @field:JsonProperty("productsServicesTypeAdditionalInfo") val productsServicesTypeAdditionalInfo: kotlin.String? = null
) {

}

