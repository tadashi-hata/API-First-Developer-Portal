package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
 * 
 * @param code Traz o código do ramo da atividade principal da empresa consultada, segundo padrão CNAE (Classificação Nacional de Atividades Econômicas) 
 * @param isMain Indica se é o ramo principal de atividade da empresa quando true e se é o ramo secundário quando false.
 */
data class EconomicActivity(

    @Schema(example = "8599604", required = true, description = "Traz o código do ramo da atividade principal da empresa consultada, segundo padrão CNAE (Classificação Nacional de Atividades Econômicas) ")
    @field:JsonProperty("code", required = true) val code: java.math.BigDecimal,

    @Schema(example = "true", required = true, description = "Indica se é o ramo principal de atividade da empresa quando true e se é o ramo secundário quando false.")
    @field:JsonProperty("isMain", required = true) val isMain: kotlin.Boolean
) {

}

