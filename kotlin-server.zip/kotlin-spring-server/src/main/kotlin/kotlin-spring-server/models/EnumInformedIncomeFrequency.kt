package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonValue
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
* Traz a frequência ou período da renda informada.
* Values: dIARIA,sEMANAL,qUINZENAL,mENSAL,bIMESTRAL,tRIMESTRAL,sEMESTRAL,aNUAL,sEMFREQUENCIARENDAINFORMADA,oUTROS
*/
enum class EnumInformedIncomeFrequency(val value: kotlin.String) {

    @JsonProperty("DIARIA") dIARIA("DIARIA"),
    @JsonProperty("SEMANAL") sEMANAL("SEMANAL"),
    @JsonProperty("QUINZENAL") qUINZENAL("QUINZENAL"),
    @JsonProperty("MENSAL") mENSAL("MENSAL"),
    @JsonProperty("BIMESTRAL") bIMESTRAL("BIMESTRAL"),
    @JsonProperty("TRIMESTRAL") tRIMESTRAL("TRIMESTRAL"),
    @JsonProperty("SEMESTRAL") sEMESTRAL("SEMESTRAL"),
    @JsonProperty("ANUAL") aNUAL("ANUAL"),
    @JsonProperty("SEM_FREQUENCIA_RENDA_INFORMADA") sEMFREQUENCIARENDAINFORMADA("SEM_FREQUENCIA_RENDA_INFORMADA"),
    @JsonProperty("OUTROS") oUTROS("OUTROS")
}

