package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonValue
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid

/**
 * 
 * @param type Tipo de representante. Representante legal - Nome Civil completo da Pessoa Natural que represente uma entidade ou uma empresa e é nomeado em seu ato constitutivo, ou seja, no contrato social ou estatuto social. Procurador - é qualquer pessoa que represente a Pessoa Natural em algum negócio, mediante autorização escrita do mesmo. 
 * @param cnpjCpfNumber Identificação do Representante Legal ou Procurador. Número do cadastro nas Receita Federal  (Preencher com CPF ou CNPJ sem formatação)
 * @param civilName Nome civil completo ou Razão Social
 * @param socialName Nome social da pessoa natural, se houver. Aquele pelo qual travestis e transexuais se reconhecem,  bem como são identificados por sua comunidade e em seu meio social, conforme Decreto Local. [Restrição] Preenchimento obrigatório quando o sócio for uma pessoa natural. 
 */
data class BusinessProcurator(

    @get:Size(max=19)
    @field:JsonProperty("type", required = true) val type: BusinessProcurator.Type,
    @get:Pattern(regexp="^\\d{11}$|^\\d{14}$|^NA$")
    @get:Size(max=14)
    @field:JsonProperty("cnpjCpfNumber", required = true) val cnpjCpfNumber: kotlin.String,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @field:JsonProperty("civilName", required = true) val civilName: kotlin.String,
    @get:Pattern(regexp="[\\w\\W\\s]*")
    @get:Size(max=70)
    @field:JsonProperty("socialName", required = true) val socialName: kotlin.String
) {

    /**
    * Tipo de representante. Representante legal - Nome Civil completo da Pessoa Natural que represente uma entidade ou uma empresa e é nomeado em seu ato constitutivo, ou seja, no contrato social ou estatuto social. Procurador - é qualquer pessoa que represente a Pessoa Natural em algum negócio, mediante autorização escrita do mesmo. 
    * Values: rEPRESENTANTELEGAL,pROCURADOR,nAOPOSSUI
    */
    enum class Type(val value: kotlin.String) {
    
        @JsonProperty("REPRESENTANTE_LEGAL") rEPRESENTANTELEGAL("REPRESENTANTE_LEGAL"),
    
        @JsonProperty("PROCURADOR") pROCURADOR("PROCURADOR"),
    
        @JsonProperty("NAO_POSSUI") nAOPOSSUI("NAO_POSSUI");
    
    }

}

