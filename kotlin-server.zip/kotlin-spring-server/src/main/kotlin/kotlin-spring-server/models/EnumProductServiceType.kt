package kotlin-spring-server.models

import java.util.Objects
import com.fasterxml.jackson.annotation.JsonValue
import com.fasterxml.jackson.annotation.JsonProperty
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size
import javax.validation.Valid
import io.swagger.v3.oas.annotations.media.Schema

/**
* Lista com a relação dos produtos e serviços com contrato vigente.
* Values: cONTADEPOSITOAVISTA,cONTAPOUPANCA,cONTAPAGAMENTOPREPAGA,cARTAOCREDITO,oPERACAOCREDITO,sEGURO,pREVIDENCIA,iNVESTIMENTO,oPERACOESCAMBIO,cONTASALARIO,cREDENCIAMENTO,oUTROS
*/
enum class EnumProductServiceType(val value: kotlin.String) {

    @JsonProperty("CONTA_DEPOSITO_A_VISTA") cONTADEPOSITOAVISTA("CONTA_DEPOSITO_A_VISTA"),
    @JsonProperty("CONTA_POUPANCA") cONTAPOUPANCA("CONTA_POUPANCA"),
    @JsonProperty("CONTA_PAGAMENTO_PRE_PAGA") cONTAPAGAMENTOPREPAGA("CONTA_PAGAMENTO_PRE_PAGA"),
    @JsonProperty("CARTAO_CREDITO") cARTAOCREDITO("CARTAO_CREDITO"),
    @JsonProperty("OPERACAO_CREDITO") oPERACAOCREDITO("OPERACAO_CREDITO"),
    @JsonProperty("SEGURO") sEGURO("SEGURO"),
    @JsonProperty("PREVIDENCIA") pREVIDENCIA("PREVIDENCIA"),
    @JsonProperty("INVESTIMENTO") iNVESTIMENTO("INVESTIMENTO"),
    @JsonProperty("OPERACOES_CAMBIO") oPERACOESCAMBIO("OPERACOES_CAMBIO"),
    @JsonProperty("CONTA_SALARIO") cONTASALARIO("CONTA_SALARIO"),
    @JsonProperty("CREDENCIAMENTO") cREDENCIAMENTO("CREDENCIAMENTO"),
    @JsonProperty("OUTROS") oUTROS("OUTROS")
}

