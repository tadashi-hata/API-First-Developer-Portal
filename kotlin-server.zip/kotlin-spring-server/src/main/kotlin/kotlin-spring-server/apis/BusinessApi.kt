package kotlin-spring-server.apis

import kotlin-spring-server.models.ResponseBusinessCustomersFinancialRelation
import kotlin-spring-server.models.ResponseBusinessCustomersIdentification
import kotlin-spring-server.models.ResponseBusinessCustomersQualification
import kotlin-spring-server.models.ResponseError
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity

import org.springframework.web.bind.annotation.*
import org.springframework.validation.annotation.Validated
import org.springframework.web.context.request.NativeWebRequest
import org.springframework.beans.factory.annotation.Autowired

import javax.validation.Valid
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size

import kotlin.collections.List
import kotlin.collections.Map

@RestController
@Validated
@RequestMapping("\${api.base-path:/open-banking/customers/v1}")
class BusinessApiController() {


    @RequestMapping(
        method = [RequestMethod.GET],
        value = ["/business/financial-relations"],
        produces = ["application/json", "application/json; charset=utf-8"]
    )
    fun customersGetBusinessFinancialRelations( @RequestHeader(value="Authorization", required=true) authorization: kotlin.String
, @RequestHeader(value="x-fapi-auth-date", required=false) xFapiAuthDate: kotlin.String?
, @RequestHeader(value="x-fapi-customer-ip-address", required=false) xFapiCustomerIpAddress: kotlin.String?
, @RequestHeader(value="x-fapi-interaction-id", required=false) xFapiInteractionId: kotlin.String?
, @RequestHeader(value="x-customer-user-agent", required=false) xCustomerUserAgent: kotlin.String?
): ResponseEntity<ResponseBusinessCustomersFinancialRelation> {
        return ResponseEntity(HttpStatus.NOT_IMPLEMENTED)
    }


    @RequestMapping(
        method = [RequestMethod.GET],
        value = ["/business/identifications"],
        produces = ["application/json", "application/json; charset=utf-8"]
    )
    fun customersGetBusinessIdentifications( @RequestHeader(value="Authorization", required=true) authorization: kotlin.String
, @RequestHeader(value="x-fapi-auth-date", required=false) xFapiAuthDate: kotlin.String?
, @RequestHeader(value="x-fapi-customer-ip-address", required=false) xFapiCustomerIpAddress: kotlin.String?
, @RequestHeader(value="x-fapi-interaction-id", required=false) xFapiInteractionId: kotlin.String?
, @RequestHeader(value="x-customer-user-agent", required=false) xCustomerUserAgent: kotlin.String?
): ResponseEntity<ResponseBusinessCustomersIdentification> {
        return ResponseEntity(HttpStatus.NOT_IMPLEMENTED)
    }


    @RequestMapping(
        method = [RequestMethod.GET],
        value = ["/business/qualifications"],
        produces = ["application/json", "application/json; charset=utf-8"]
    )
    fun customersGetBusinessQualifications( @RequestHeader(value="Authorization", required=true) authorization: kotlin.String
, @RequestHeader(value="x-fapi-auth-date", required=false) xFapiAuthDate: kotlin.String?
, @RequestHeader(value="x-fapi-customer-ip-address", required=false) xFapiCustomerIpAddress: kotlin.String?
, @RequestHeader(value="x-fapi-interaction-id", required=false) xFapiInteractionId: kotlin.String?
, @RequestHeader(value="x-customer-user-agent", required=false) xCustomerUserAgent: kotlin.String?
): ResponseEntity<ResponseBusinessCustomersQualification> {
        return ResponseEntity(HttpStatus.NOT_IMPLEMENTED)
    }
}
