package kotlin-spring-server.apis

import kotlin-spring-server.models.ResponseError
import kotlin-spring-server.models.ResponsePersonalCustomersFinancialRelation
import kotlin-spring-server.models.ResponsePersonalCustomersIdentification
import kotlin-spring-server.models.ResponsePersonalCustomersQualification
import io.swagger.v3.oas.annotations.*
import io.swagger.v3.oas.annotations.enums.*
import io.swagger.v3.oas.annotations.media.*
import io.swagger.v3.oas.annotations.responses.*
import io.swagger.v3.oas.annotations.security.*
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity

import org.springframework.web.bind.annotation.*
import org.springframework.validation.annotation.Validated
import org.springframework.web.context.request.NativeWebRequest
import org.springframework.beans.factory.annotation.Autowired

import javax.validation.Valid
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Email
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size

import kotlin.collections.List
import kotlin.collections.Map

@RestController
@Validated
@RequestMapping("\${api.base-path:/open-banking/customers/v1}")
class PersonalApiController() {

    @Operation(
        summary = "Obtém os registros de relacionamentos com a instituição financeira e de representantes da pessoa natural.",
        operationId = "customersGetPersonalFinancialRelations",
        description = "Método para obter registros de relacionamentos com a instituição financeira e de representantes da pessoa natural mantidos na instituição transmissora.",
        responses = [
            ApiResponse(responseCode = "200", description = "Dados sobre relacionamento da pessoa física", content = [Content(schema = Schema(implementation = ResponsePersonalCustomersFinancialRelation::class))]),
            ApiResponse(responseCode = "400", description = "A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL.", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "401", description = "Cabeçalho de autenticação ausente/inválido ou token inválido", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "403", description = "O token tem escopo incorreto ou uma política de segurança foi violada", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "404", description = "O recurso solicitado não existe ou não foi implementado", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "405", description = "O consumidor tentou acessar o recurso com um método não suportado", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "406", description = "A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "429", description = "A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "500", description = "Ocorreu um erro no gateway da API ou no microsserviço", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "200", description = "Dados sobre relacionamento da pessoa física", content = [Content(schema = Schema(implementation = ResponsePersonalCustomersFinancialRelation::class))]) ],
        security = [ SecurityRequirement(name = "OAuth2Security", scopes = [ "customers" ]) ]
    )
    @RequestMapping(
        method = [RequestMethod.GET],
        value = ["/personal/financial-relations"],
        produces = ["application/json", "application/json; charset=utf-8"]
    )
    fun customersGetPersonalFinancialRelations(@Pattern(regexp="[\\w\\W\\s]*") @Size(max=2048) @Parameter(description = "Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado", `in` = ParameterIn.HEADER, required = true) @RequestHeader(value = "Authorization", required = true) authorization: kotlin.String,@Pattern(regexp="^(Mon|Tue|Wed|Thu|Fri|Sat|Sun), \\d{2} (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \\d{4} \\d{2}:\\d{2}:\\d{2} (GMT|UTC)$") @Size(min=29,max=29) @Parameter(description = "Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC", `in` = ParameterIn.HEADER) @RequestHeader(value = "x-fapi-auth-date", required = false) xFapiAuthDate: kotlin.String?,@Pattern(regexp="[\\w\\W\\s]*") @Size(min=1,max=100) @Parameter(description = "O endereço IP do usuário se estiver atualmente logado com o receptor.", `in` = ParameterIn.HEADER) @RequestHeader(value = "x-fapi-customer-ip-address", required = false) xFapiCustomerIpAddress: kotlin.String?,@Pattern(regexp="^[a-zA-Z0-9][a-zA-Z0-9\\-]{0,99}$") @Size(min=1,max=100) @Parameter(description = "Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve \"reproduzir\" esse valor no cabeçalho de resposta.", `in` = ParameterIn.HEADER) @RequestHeader(value = "x-fapi-interaction-id", required = false) xFapiInteractionId: kotlin.String?,@Pattern(regexp="[\\w\\W\\s]*") @Size(min=1,max=100) @Parameter(description = "Indica o user-agent que o usuário utiliza.", `in` = ParameterIn.HEADER) @RequestHeader(value = "x-customer-user-agent", required = false) xCustomerUserAgent: kotlin.String?): ResponseEntity<ResponsePersonalCustomersFinancialRelation> {
        return ResponseEntity(HttpStatus.NOT_IMPLEMENTED)
    }

    @Operation(
        summary = "Obtém os registros de identificação da pessoa natural.",
        operationId = "customersGetPersonalIdentifications",
        description = "Método para obter os registros de identificação da pessoa natural mantidos na instituição transmissora.",
        responses = [
            ApiResponse(responseCode = "200", description = "Dados sobre identificação pessoa física.", content = [Content(schema = Schema(implementation = ResponsePersonalCustomersIdentification::class))]),
            ApiResponse(responseCode = "400", description = "A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL.", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "401", description = "Cabeçalho de autenticação ausente/inválido ou token inválido", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "403", description = "O token tem escopo incorreto ou uma política de segurança foi violada", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "404", description = "O recurso solicitado não existe ou não foi implementado", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "405", description = "O consumidor tentou acessar o recurso com um método não suportado", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "406", description = "A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "429", description = "A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "500", description = "Ocorreu um erro no gateway da API ou no microsserviço", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "200", description = "Dados sobre identificação pessoa física.", content = [Content(schema = Schema(implementation = ResponsePersonalCustomersIdentification::class))]) ],
        security = [ SecurityRequirement(name = "OAuth2Security", scopes = [ "customers" ]) ]
    )
    @RequestMapping(
        method = [RequestMethod.GET],
        value = ["/personal/identifications"],
        produces = ["application/json", "application/json; charset=utf-8"]
    )
    fun customersGetPersonalIdentifications(@Pattern(regexp="[\\w\\W\\s]*") @Size(max=2048) @Parameter(description = "Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado", `in` = ParameterIn.HEADER, required = true) @RequestHeader(value = "Authorization", required = true) authorization: kotlin.String,@Pattern(regexp="^(Mon|Tue|Wed|Thu|Fri|Sat|Sun), \\d{2} (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \\d{4} \\d{2}:\\d{2}:\\d{2} (GMT|UTC)$") @Size(min=29,max=29) @Parameter(description = "Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC", `in` = ParameterIn.HEADER) @RequestHeader(value = "x-fapi-auth-date", required = false) xFapiAuthDate: kotlin.String?,@Pattern(regexp="[\\w\\W\\s]*") @Size(min=1,max=100) @Parameter(description = "O endereço IP do usuário se estiver atualmente logado com o receptor.", `in` = ParameterIn.HEADER) @RequestHeader(value = "x-fapi-customer-ip-address", required = false) xFapiCustomerIpAddress: kotlin.String?,@Pattern(regexp="^[a-zA-Z0-9][a-zA-Z0-9\\-]{0,99}$") @Size(min=1,max=100) @Parameter(description = "Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve \"reproduzir\" esse valor no cabeçalho de resposta.", `in` = ParameterIn.HEADER) @RequestHeader(value = "x-fapi-interaction-id", required = false) xFapiInteractionId: kotlin.String?,@Pattern(regexp="[\\w\\W\\s]*") @Size(min=1,max=100) @Parameter(description = "Indica o user-agent que o usuário utiliza.", `in` = ParameterIn.HEADER) @RequestHeader(value = "x-customer-user-agent", required = false) xCustomerUserAgent: kotlin.String?): ResponseEntity<ResponsePersonalCustomersIdentification> {
        return ResponseEntity(HttpStatus.NOT_IMPLEMENTED)
    }

    @Operation(
        summary = "Obtém os registros de qualificação da pessoa natural.",
        operationId = "customersGetPersonalQualifications",
        description = "Método para obter os registros de qualificação da pessoa natural mantidos na instituição transmissora.",
        responses = [
            ApiResponse(responseCode = "200", description = "Dados sobre qualificação da pessoa física", content = [Content(schema = Schema(implementation = ResponsePersonalCustomersQualification::class))]),
            ApiResponse(responseCode = "400", description = "A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL.", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "401", description = "Cabeçalho de autenticação ausente/inválido ou token inválido", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "403", description = "O token tem escopo incorreto ou uma política de segurança foi violada", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "404", description = "O recurso solicitado não existe ou não foi implementado", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "405", description = "O consumidor tentou acessar o recurso com um método não suportado", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "406", description = "A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "429", description = "A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "500", description = "Ocorreu um erro no gateway da API ou no microsserviço", content = [Content(schema = Schema(implementation = ResponseError::class))]),
            ApiResponse(responseCode = "200", description = "Dados sobre qualificação da pessoa física", content = [Content(schema = Schema(implementation = ResponsePersonalCustomersQualification::class))]) ],
        security = [ SecurityRequirement(name = "OAuth2Security", scopes = [ "customers" ]) ]
    )
    @RequestMapping(
        method = [RequestMethod.GET],
        value = ["/personal/qualifications"],
        produces = ["application/json", "application/json; charset=utf-8"]
    )
    fun customersGetPersonalQualifications(@Pattern(regexp="[\\w\\W\\s]*") @Size(max=2048) @Parameter(description = "Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado", `in` = ParameterIn.HEADER, required = true) @RequestHeader(value = "Authorization", required = true) authorization: kotlin.String,@Pattern(regexp="^(Mon|Tue|Wed|Thu|Fri|Sat|Sun), \\d{2} (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \\d{4} \\d{2}:\\d{2}:\\d{2} (GMT|UTC)$") @Size(min=29,max=29) @Parameter(description = "Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC", `in` = ParameterIn.HEADER) @RequestHeader(value = "x-fapi-auth-date", required = false) xFapiAuthDate: kotlin.String?,@Pattern(regexp="[\\w\\W\\s]*") @Size(min=1,max=100) @Parameter(description = "O endereço IP do usuário se estiver atualmente logado com o receptor.", `in` = ParameterIn.HEADER) @RequestHeader(value = "x-fapi-customer-ip-address", required = false) xFapiCustomerIpAddress: kotlin.String?,@Pattern(regexp="^[a-zA-Z0-9][a-zA-Z0-9\\-]{0,99}$") @Size(min=1,max=100) @Parameter(description = "Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve \"reproduzir\" esse valor no cabeçalho de resposta.", `in` = ParameterIn.HEADER) @RequestHeader(value = "x-fapi-interaction-id", required = false) xFapiInteractionId: kotlin.String?,@Pattern(regexp="[\\w\\W\\s]*") @Size(min=1,max=100) @Parameter(description = "Indica o user-agent que o usuário utiliza.", `in` = ParameterIn.HEADER) @RequestHeader(value = "x-customer-user-agent", required = false) xCustomerUserAgent: kotlin.String?): ResponseEntity<ResponsePersonalCustomersQualification> {
        return ResponseEntity(HttpStatus.NOT_IMPLEMENTED)
    }
}
