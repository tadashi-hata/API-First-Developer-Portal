package kotlin-spring-server.apis

import kotlin-spring-server.models.ResponseError
import kotlin-spring-server.models.ResponsePersonalCustomersFinancialRelation
import kotlin-spring-server.models.ResponsePersonalCustomersIdentification
import kotlin-spring-server.models.ResponsePersonalCustomersQualification
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity

import org.springframework.web.bind.annotation.*
import org.springframework.validation.annotation.Validated
import org.springframework.web.context.request.NativeWebRequest
import org.springframework.beans.factory.annotation.Autowired

import javax.validation.Valid
import javax.validation.constraints.DecimalMax
import javax.validation.constraints.DecimalMin
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import javax.validation.constraints.Size

import kotlin.collections.List
import kotlin.collections.Map

@RestController
@Validated
@RequestMapping("\${api.base-path:/open-banking/customers/v1}")
class PersonalApiController() {


    @RequestMapping(
        method = [RequestMethod.GET],
        value = ["/personal/financial-relations"],
        produces = ["application/json", "application/json; charset=utf-8"]
    )
    fun customersGetPersonalFinancialRelations( @RequestHeader(value="Authorization", required=true) authorization: kotlin.String
, @RequestHeader(value="x-fapi-auth-date", required=false) xFapiAuthDate: kotlin.String?
, @RequestHeader(value="x-fapi-customer-ip-address", required=false) xFapiCustomerIpAddress: kotlin.String?
, @RequestHeader(value="x-fapi-interaction-id", required=false) xFapiInteractionId: kotlin.String?
, @RequestHeader(value="x-customer-user-agent", required=false) xCustomerUserAgent: kotlin.String?
): ResponseEntity<ResponsePersonalCustomersFinancialRelation> {
        return ResponseEntity(HttpStatus.NOT_IMPLEMENTED)
    }


    @RequestMapping(
        method = [RequestMethod.GET],
        value = ["/personal/identifications"],
        produces = ["application/json", "application/json; charset=utf-8"]
    )
    fun customersGetPersonalIdentifications( @RequestHeader(value="Authorization", required=true) authorization: kotlin.String
, @RequestHeader(value="x-fapi-auth-date", required=false) xFapiAuthDate: kotlin.String?
, @RequestHeader(value="x-fapi-customer-ip-address", required=false) xFapiCustomerIpAddress: kotlin.String?
, @RequestHeader(value="x-fapi-interaction-id", required=false) xFapiInteractionId: kotlin.String?
, @RequestHeader(value="x-customer-user-agent", required=false) xCustomerUserAgent: kotlin.String?
): ResponseEntity<ResponsePersonalCustomersIdentification> {
        return ResponseEntity(HttpStatus.NOT_IMPLEMENTED)
    }


    @RequestMapping(
        method = [RequestMethod.GET],
        value = ["/personal/qualifications"],
        produces = ["application/json", "application/json; charset=utf-8"]
    )
    fun customersGetPersonalQualifications( @RequestHeader(value="Authorization", required=true) authorization: kotlin.String
, @RequestHeader(value="x-fapi-auth-date", required=false) xFapiAuthDate: kotlin.String?
, @RequestHeader(value="x-fapi-customer-ip-address", required=false) xFapiCustomerIpAddress: kotlin.String?
, @RequestHeader(value="x-fapi-interaction-id", required=false) xFapiInteractionId: kotlin.String?
, @RequestHeader(value="x-customer-user-agent", required=false) xCustomerUserAgent: kotlin.String?
): ResponseEntity<ResponsePersonalCustomersQualification> {
        return ResponseEntity(HttpStatus.NOT_IMPLEMENTED)
    }
}
