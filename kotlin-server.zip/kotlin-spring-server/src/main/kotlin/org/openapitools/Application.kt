package org.openapitools

import org.springframework.boot.runApplication
import org.springframework.context.annotation.ComponentScan
import org.springframework.boot.autoconfigure.SpringBootApplication


@SpringBootApplication
@ComponentScan(basePackages = ["org.openapitools", "kotlin-spring-server.apis", "kotlin-spring-server.models"])
class Application

fun main(args: Array<String>) {
    runApplication<Application>(*args)
}
