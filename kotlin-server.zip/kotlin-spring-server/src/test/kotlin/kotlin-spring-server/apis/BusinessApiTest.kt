package kotlin-spring-server.apis

import kotlin-spring-server.models.ResponseBusinessCustomersFinancialRelation
import kotlin-spring-server.models.ResponseBusinessCustomersIdentification
import kotlin-spring-server.models.ResponseBusinessCustomersQualification
import kotlin-spring-server.models.ResponseError
import org.junit.jupiter.api.Test
import org.springframework.http.ResponseEntity

class BusinessApiTest {

    private val api: BusinessApiController = BusinessApiController()

    /**
     * To test BusinessApiController.customersGetBusinessFinancialRelations
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    fun customersGetBusinessFinancialRelationsTest() {
        val authorization:kotlin.String? = null
        val xFapiAuthDate:kotlin.String? = null
        val xFapiCustomerIpAddress:kotlin.String? = null
        val xFapiInteractionId:kotlin.String? = null
        val xCustomerUserAgent:kotlin.String? = null
        val response: ResponseEntity<ResponseBusinessCustomersFinancialRelation> = api.customersGetBusinessFinancialRelations(authorization, xFapiAuthDate, xFapiCustomerIpAddress, xFapiInteractionId, xCustomerUserAgent)

        // TODO: test validations
    }

    /**
     * To test BusinessApiController.customersGetBusinessIdentifications
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    fun customersGetBusinessIdentificationsTest() {
        val authorization:kotlin.String? = null
        val xFapiAuthDate:kotlin.String? = null
        val xFapiCustomerIpAddress:kotlin.String? = null
        val xFapiInteractionId:kotlin.String? = null
        val xCustomerUserAgent:kotlin.String? = null
        val response: ResponseEntity<ResponseBusinessCustomersIdentification> = api.customersGetBusinessIdentifications(authorization, xFapiAuthDate, xFapiCustomerIpAddress, xFapiInteractionId, xCustomerUserAgent)

        // TODO: test validations
    }

    /**
     * To test BusinessApiController.customersGetBusinessQualifications
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    fun customersGetBusinessQualificationsTest() {
        val authorization:kotlin.String? = null
        val xFapiAuthDate:kotlin.String? = null
        val xFapiCustomerIpAddress:kotlin.String? = null
        val xFapiInteractionId:kotlin.String? = null
        val xCustomerUserAgent:kotlin.String? = null
        val response: ResponseEntity<ResponseBusinessCustomersQualification> = api.customersGetBusinessQualifications(authorization, xFapiAuthDate, xFapiCustomerIpAddress, xFapiInteractionId, xCustomerUserAgent)

        // TODO: test validations
    }

}
