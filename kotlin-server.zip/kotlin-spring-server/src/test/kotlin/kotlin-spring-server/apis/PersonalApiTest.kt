package kotlin-spring-server.apis

import kotlin-spring-server.models.ResponseError
import kotlin-spring-server.models.ResponsePersonalCustomersFinancialRelation
import kotlin-spring-server.models.ResponsePersonalCustomersIdentification
import kotlin-spring-server.models.ResponsePersonalCustomersQualification
import org.junit.jupiter.api.Test
import org.springframework.http.ResponseEntity

class PersonalApiTest {

    private val api: PersonalApiController = PersonalApiController()

    /**
     * To test PersonalApiController.customersGetPersonalFinancialRelations
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    fun customersGetPersonalFinancialRelationsTest() {
        val authorization: kotlin.String = TODO()
        val xFapiAuthDate: kotlin.String? = TODO()
        val xFapiCustomerIpAddress: kotlin.String? = TODO()
        val xFapiInteractionId: kotlin.String? = TODO()
        val xCustomerUserAgent: kotlin.String? = TODO()
        val response: ResponseEntity<ResponsePersonalCustomersFinancialRelation> = api.customersGetPersonalFinancialRelations(authorization, xFapiAuthDate, xFapiCustomerIpAddress, xFapiInteractionId, xCustomerUserAgent)

        // TODO: test validations
    }

    /**
     * To test PersonalApiController.customersGetPersonalIdentifications
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    fun customersGetPersonalIdentificationsTest() {
        val authorization: kotlin.String = TODO()
        val xFapiAuthDate: kotlin.String? = TODO()
        val xFapiCustomerIpAddress: kotlin.String? = TODO()
        val xFapiInteractionId: kotlin.String? = TODO()
        val xCustomerUserAgent: kotlin.String? = TODO()
        val response: ResponseEntity<ResponsePersonalCustomersIdentification> = api.customersGetPersonalIdentifications(authorization, xFapiAuthDate, xFapiCustomerIpAddress, xFapiInteractionId, xCustomerUserAgent)

        // TODO: test validations
    }

    /**
     * To test PersonalApiController.customersGetPersonalQualifications
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    fun customersGetPersonalQualificationsTest() {
        val authorization: kotlin.String = TODO()
        val xFapiAuthDate: kotlin.String? = TODO()
        val xFapiCustomerIpAddress: kotlin.String? = TODO()
        val xFapiInteractionId: kotlin.String? = TODO()
        val xCustomerUserAgent: kotlin.String? = TODO()
        val response: ResponseEntity<ResponsePersonalCustomersQualification> = api.customersGetPersonalQualifications(authorization, xFapiAuthDate, xFapiCustomerIpAddress, xFapiInteractionId, xCustomerUserAgent)

        // TODO: test validations
    }
}
