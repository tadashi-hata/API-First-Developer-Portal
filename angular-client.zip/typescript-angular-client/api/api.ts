export * from './customers.service';
import { CustomersService } from './customers.service';
export const APIS = [CustomersService];
